package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.example.data.*
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

// Visual Theme Colors matching client specifications - dynamic for custom preferences and light/dark theme
var ThemeGold by mutableStateOf(Color(0xFFD4AF37))
var ThemeGoldLight by mutableStateOf(Color(0xFFF0D060))
var ThemeRed by mutableStateOf(Color(0xFFC0392B))
var DarkBackground by mutableStateOf(Color(0xFF090909))
var DarkSurface by mutableStateOf(Color(0xFF141414))
var DarkSurfaceElevated by mutableStateOf(Color(0xFF1E1E1E))
var TextLight by mutableStateOf(Color(0xFFF1EADF))
var TextMuted by mutableStateOf(Color(0xFFA59E8E))

data class LearningLevel(
    val number: Int,
    val title: String,
    val arabicTitle: String,
    val category: String,
    val levelNum: Int,
    val requiredXP: Int,
    val description: String,
    val icon: String
)

val learningLevelsList = listOf(
    LearningLevel(1, "الأساسيات والترحيب 👋", "التحيات والأوّلية", "التحيات", 1, 0, "تعرّف على أهم مفردات التحية والترحيب والتواصل البسيط بالصينية.", "👋"),
    LearningLevel(2, "الأرقام والعد الصيني 🔢", "الأرقام والحساب", "أرقام", 1, 100, "أتقن طريقة نطق وكتابة الأرقام الصينية من ١ حتى ١٠٠ بسهولة.", "🔢"),
    LearningLevel(3, "العائلة والأقارب 👨‍👩‍👧‍👦", "روابط العائلة والدم", "العائلة", 1, 230, "تعلم كيفية مناداة أفراد العائلة والأقارب وبناء حوار اجتماعي بسيط.", "👨‍👩‍👧‍👦"),
    LearningLevel(4, "الأفعال والحركات اليومية 🏃‍♂️", "الأفعال الأساسية", "أفعال", 1, 450, "مجموعة الأفعال الأكثر استخداماً للتعبير عن الحركة والنشاطات.", "🏃‍♂️"),
    LearningLevel(5, "الطعام والمأكولات اللذيذة 🍎", "الطعام والمشروبات", "طعام", 1, 750, "تعلم كيفية التعبير عن الطعام، والوجبات والمشروبات الصينية الشهيرة.", "🍎"),
    LearningLevel(6, "التسوق والتبادل المالي 💰", "التجارة والشراء", "تجارة", 2, 1100, "أتقن مهارات المساومة والتفاوض على الأسعار والتسوق كالمحترفين.", "💰")
)

// ==============================================
// 📢 إعدادات معرفات الإعلانات للتطبيق (AD CONFIGURATIONS)
// قم بوضع المعرفات الخاصة بك هنا مباشرة وسيقوم التطبيق باستخدامها تلقائياً.
// ==============================================
object AppAdConfig {
    // 1️⃣ معرفات إعلانات جوجل ادموب (Google AdMob Unit IDs)
    const val ADMOB_BANNER_AD_ID = "ca-app-pub-9154986745650992/7903493015" // ضع معرف إعلان البنر هنا (AdMob Banner)
    const val ADMOB_INTERSTITIAL_AD_ID = "ca-app-pub-9154986745650992/7713056798" // ضع معرف إعلان البيني هنا (AdMob Interstitial)

    // 2️⃣ معرفات إعلانات هواوي (Huawei Ads Unit IDs)
    const val HUAWEI_BANNER_AD_ID = "" // ضع معرف إعلان البنر لهواوي هنا (Huawei Banner)
    const val HUAWEI_INTERSTITIAL_AD_ID = "" // ضع معرف إعلان البيني لهواوي هنا (Huawei Interstitial)
}
// ==============================================

val TranslationMap = mapOf(
    "الرئيسية" to "Home",
    "القاموس" to "Dictionary",
    "الحوارات" to "Dialogues",
    "المساعد" to "AI Mentor",
    "التمارين" to "Exercises",
    "المستخدم" to "Profile",
    "التحيات" to "Greetings",
    "ضمائر" to "Pronouns",
    "العائلة" to "Family",
    "أفعال" to "Verbs",
    "طعام" to "Food",
    "العلاقات" to "Relationships",
    "تجارة" to "Commerce",
    "تاريخ ووقت" to "Time & Date",
    "أرقام" to "Numbers",
    "صيغ المعدود" to "Measure Words",
    "جمل أساسية" to "Basic Sentences",
    "تجارة وتسوق" to "Shopping",
    "وظائف" to "Careers",
    "وجهات" to "Destinations",
    "السفر" to "Travel",
    "الكل" to "All",
    "تصفية بالتصنيفات" to "Filter By Categories",
    "مستوى" to "Level",
    "حفظ الكلمة" to "Save Word",
    "إتمام الحفظ" to "Saved",
    "تعلّم" to "Learned",
    "تم الحفظ" to "Saved",
    "ممتاز!" to "Excellent!",
    "لقد حصلت على 10 نقاط خبرة." to "You gained 10 XP.",
    "تهانينا!" to "Congratulations!",
    "إلغاء الحساب" to "De-authorize",
    "بحث..." to "Search...",
    "البحث عن كلمة صينية أو عربية..." to "Search Chinese or Arabic...",
    "اكتب رسالتك باللغة العربية..." to "Ask me in Arabic/English...",
    "أرسل" to "Send",
    "الوضع المظهر" to "Appearance Mode",
    "مظهر داكن" to "Dark Mode",
    "مظهر فاتح" to "Light Mode",
    "السمة اللونية" to "Color Theme",
    "ذهبي ملكي" to "Royal Gold",
    "أزرق سماوي" to "Sky Blue",
    "أخضر زمردي" to "Emerald Green",
    "أرجواني ملكي" to "Imperial Purple",
    "أحمر مرجاني" to "Coral Red",
    "تنبيهات المذكّر الصباحي" to "Morning Reminder Notifications",
    "سرعة محاكاة نطق الكلمات الصينية" to "Chinese Speech Speed Simulation",
    "تغيير لغة التطبيق" to "Language Settings",
    "لغة الواجهة والحديث:" to "App Language:",
    "العربية" to "Arabic",
    "العربية (Arabic)" to "العربية (Arabic)",
    "الإنجليزية (English)" to "English (English)",
    "سرعة" to "Speed",
    "مستوى التعلم الحالي" to "Your Learning Progress",
    "النقاط المطلوبة" to "Required Points",
    "إعلان" to "AD / Sponsored",
    "معلومات الإعلانات" to "Ad Settings Info",
    "مغلق" to "Locked",
    "تخطى" to "Skip",
    "متابعة" to "Continue",
    "ابدأ الاختبار" to "Start Quiz",
    "ابدأ التدريب" to "Start Warm-up",
    "اختبار فوري" to "Quick Quiz",
    "السؤال الحالي:" to "Current Question:",
    "اختر الإجابة الصحيحة المقابلة للكلمة:" to "Choose the matching translation:",
    "لقد أكملت الاختبار وحصلت على النقاط!" to "You completed the quiz and earned XP!",
    "تعديل الإعدادات" to "Modify Settings",
    "الإعدادات العامة" to "General Settings",
    "كلمة اليوم العشوائية" to "Daily Word Spotlight",
    "اضغط للاستماع" to "Tap to Listen / Pronounce",
    "البينين" to "Pinyin",
    "الترجمة:" to "Translation:",
    "أهلاً بك في هواة هويو تونغ!" to "Welcome to Huayutong Studio!",
    "هنا نوفر لك تجربة تعليمية فائقة وفريدة لرحلتك الصينية الحديثة." to "Learn Chinese the fast and easy way with professional audio and responsive exercises.",
    "مستوى التطوير المكتمل:" to "Course completion statistics:",
    "كلمات القاموس" to "Dictionary vocabulary",
    "أيام متتالية" to "days streak",
    "كلمة" to "words",
    "محادثات تفاعولية" to "interactive dialogues",
    "مكتملة" to "completed",
    "محفوظة" to "bookmarked",
    "قواعد هامة" to "important rules",
    "التقييم العام" to "My Profile Stats",
    "ابدأ الحوار" to "Launch Dialogue",
    "تحتوي هذه المحادثة على" to "This conversation contains",
    "عبارات وجمل صينية واقعية" to "authentic Chinese phrases",
    "محادثة ممتعة من واقع الحياة اليومية لتنمية مهارات النطق والاستماع" to "Fun real-world dialogues to boost your speaking and listening skills.",
    "الرفيق (Speaker B)" to "Companion (Speaker B)",
    "أنت (Speaker A)" to "You (Speaker A)",
    "اضغط لجعل المساعد اللغوي ينطق العبارة الصينية بالصوت الطبيعي" to "Tap any message bubble to hear correct high-fidelity Chinese pronunciation.",
    "القواعد النحوية" to "Grammar Rules",
    "أهم قواعد وترتيب الجمل في صياغة اللغة الصينية" to "Key guidelines to structuring natural Chinese sentences beautifully.",
    "قاعدة" to "Rule",
    "المستوى:" to "Level:",
    "المستوى المقيد بـ XP" to "Restricted Level (Requires XP)",
    "استماع" to "Listen",
    "ترجمة" to "Translation",
    "تفاصيل الكلمة" to "Vocabulary Detail",
    "أغلق" to "Close",
    "أغلق النافذة" to "Close Panel",
    "حوار" to "Dialogue",
    "النقاط:" to "XP:",
    "الاستمرارية:" to "Streak:",
    "سؤال" to "Question",
    "✓ صح:" to "✓ Correct:",
    "✕ خطأ:" to "✕ Wrong:",
    "🏆 مكافأة الاختبار: +١٥ نقطة لكل صح + ١٥ مكافأة إكمال 💎" to "🏆 Quiz Reward: +15 XP per correct + 15 completion bonus 💎",
    "السؤال التالي ➡️" to "Next Question ➡️",
    "بطاقة" to "Card",
    "🃏 بطاقة الذاكرة: +١٠ نقاط لكل كارت معروف + ١٥ مكافأة إكمال 💎" to "🃏 Flashcard: +10 XP per known card + 15 completion bonus 💎",
    "انقر لقلب البطاقة وكشف المعنى" to "Tap to flip card and reveal translation",
    "العربية: " to "Arabic: ",
    "لم أعرفها ✕" to "I didn't know it ✕",
    "عرفتها ✓" to "I knew it ✓",
    "مبتدئ (HSK 1)" to "Beginner (HSK 1)",
    "مبتدئ متقدم (HSK 2)" to "Advanced Beginner (HSK 2)",
    "ابتدائي (HSK 3)" to "Elementary (HSK 3)",
    "متوسط (HSK 4)" to "Intermediate (HSK 4)",
    "متوسط متكامل (HSK 5)" to "Upper Intermediate (HSK 5)",
    "متقدم خبير (HSK 6)" to "Advanced Expert (HSK 6)",
    "مستكشف اللغة الذكي" to "Smart Language Explorer",
    "المستوى" to "Level",
    "معدل الترقية للمستوى التالي:" to "Next level promotion rate:",
    "نقاط خبرة XP" to "Experience points (XP)",
    "سلسلة الأيام" to "Streak days",
    "⚙️ إعدادات التحكم بالنطق والمظهر" to "⚙️ Speech & Appearance Controls",
    "نطق تلقائي فوري" to "Instant Auto-Pronounce",
    "تشغيل الصوت بمجرد النقر وكشف كروت الذاكرة" to "Auto-speak audio when clicked or flipped",
    "وضع مظهر التطبيق (الوضع الداكن / المضيء):" to "App Theme Mode (Dark / Light):",
    "تخصيص لون هوية التطبيق المميز 🎨:" to "Customize App Accent Color 🎨:",
    "سرعة النطق الصوتي للدروس الحالية:" to "Audio pronunciation speech speed:",
    "تصفير النقاط وبدء التعلم من جديد 🔄" to "Reset XP & start learning fresh 🔄",
    "تنبيه هام ومؤكد ⚠️" to "Important Warning ⚠️",
    "هل أنت متأكد تماماً من رغبتك في تصفير وإعادة تعيين كافة تقدمك الحالي، بما في ذلك نقاط الـ XP، والكلمات المكتملة والمفضلة المحفوظة ومختلف التفضيلات المخصصة؟ لا يمكن التراجع عن هذا الإجراء أبداً!" to "Are you absolutely sure you want to reset all your progress, XP, completed cards, bookmarks, and custom preferences? This action cannot be undone!",
    "نعم، تصفير الآن ⚠️" to "Yes, reset now ⚠️",
    "إلغاء وتراجع" to "Cancel & go back",
    "الفئة" to "Category",
    "مكافأة التعلم المباشر: +10 XP" to "Direct learning bonus: +10 XP",
    "🔊 نطق الكلمة" to "🔊 Speak Word",
    "أحسنت صنعاً! 恭喜" to "Well done! 恭喜",
    "لقد أكملت الجولة بنجاح وحققت أهدافك اللغوية لليوم وتم توثيق النتيجة وزيادة رصيد خبرتك." to "You have successfully completed the round, achieved your daily goals, and earned XP.",
    "XP نقاط خبرة" to "XP points",
    "أيام متتالية" to "days streak",
    "استلام المكافأة 💎" to "Claim Reward 💎",
    "إعلان ممول" to "Sponsored Ad",
    "إغلاق الإعلان" to "Close Ad",
    "تطبيق حوارات وكلمات الصينية رقم ١" to "The #1 Chinese Dialogue & Vocabulary App",
    "ترقية العضوية للتخلص من الإعلانات تماماً!" to "Upgrade to remove ads permanently!",
    "تخطي خلال " to "Skip in ",
    "تخطي الإعلان ✕" to "Skip Ad ✕",
    "🌟 مفضلتي الذهبية الفردية" to "🌟 My Personal Favorites",
    "قم بحفظ كلمة صينية واحدة على الأقل في قائمتك المفضلة." to "Save at least one Chinese word in your bookmarks list.",
    "🎓 التمكين الدراسي للرموز" to "🎓 Character Mastery",
    "أنجز ٣ كلمات صينية وعلّم عليها كـ 'أكملت ✅' لترسيخ حفظها ونطقها." to "Mark at least 3 words as completed to master their pronunciation.",
    "🔥 شعلة التعلم المتواصل" to "🔥 Continuous Learning Streak",
    "نشّط الحساب وتأكد من بدء شعلة Streak التعلم." to "Keep your daily learning streak alive.",
    "🤖 صديق الذكاء الاصطناعي" to "🤖 Gemini AI Mentor",
    "اطرح سؤالاً واحداً على رفيق التعلم الذكي Gemini لتوضيح القواعد." to "Ask Gemini mentor a question to clarify Chinese grammar rules.",
    "🏆 مهام التحدي والإنجازات اليومية" to "🏆 Daily Achievements & Challenges",
    "مكافآت يومية نشطة" to "Active Daily Quests",
    "مكتمل! 🎉" to "Completed! 🎉",
    "داكن 🌙" to "Dark 🌙",
    "مضيء ☀️" to "Light ☀️",
    "تلقائي 📱" to "System 📱",
    "ذهبي 👑" to "Gold 👑",
    "أزرق 💎" to "Blue 💎",
    "أخضر 🌿" to "Green 🌿",
    "بنفسجي 🔮" to "Purple 🔮",
    "أحمر 🍁" to "Red 🍁",
    "بطيء 🐢" to "Slow 🐢",
    "عادي 👤" to "Normal 👤",
    "سريع ⚡" to "Fast ⚡",
    "❤️ حفظ" to "❤️ Saved",
    "🤍 حفظ" to "🤍 Save",
    "✅ أكملت" to "✅ Completed",
    "◽ أكملت" to "◽ Uncompleted",
    "كل الحوارات" to "All Dialogues",
    "👋 التعارف والتحية" to "👋 Greetings & Info",
    "✈️ السفر والوجهات" to "✈️ Travel & Places",
    "🍽️ المطعم والوجبات" to "🍽️ Restaurant & Food",
    "🏨 الفندق والإقامة" to "🏨 Hotel & Stay",
    "🤝 التجارة والمساومة" to "🤝 Trade & Business",
    "حوارات يومية تفاعلية 💬" to "Interactive Daily Conversations 💬",
    "اختر تصنيف المواقف الحياتية الحقيقية للاستماع لنطق العبارات والتدرب عليها." to "Select a category of real life scenarios to listen to pronunciations and practice phrases.",
    "اضغط على أي عنوان حوار لعرض المحادثة والعبارات بالنطق الصوتي." to "Tap on any conversation topic to view dialogue lines and listen to audio.",
    "🔊 نقر للنطق" to "🔊 Tap to speak"
)

val LocalIsEnglish = staticCompositionLocalOf { false }

@Composable
fun tr(key: String): String {
    return tr(key, LocalIsEnglish.current)
}

fun tr(key: String, isEn: Boolean): String {
    if (key.contains("|")) {
        val parts = key.split("|")
        return if (isEn) {
            if (parts.size > 1) parts[1].trim() else parts[0].trim()
        } else {
            parts[0].trim()
        }
    }
    if (!isEn) return key
    return TranslationMap[key] ?: key
}

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()
    var mInterstitialAd: InterstitialAd? = null

    fun loadInterstitialAd() {
        try {
            val adRequest = AdRequest.Builder().build()
            val adUnitId = AppAdConfig.ADMOB_INTERSTITIAL_AD_ID.ifEmpty { "ca-app-pub-9154986745650992/7713056798" }
            InterstitialAd.load(this, adUnitId, adRequest, object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    mInterstitialAd = null
                }
                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    mInterstitialAd = interstitialAd
                }
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            MobileAds.initialize(this) {}
            loadInterstitialAd()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        DailyReminderReceiver.scheduleDailyNotification(this)
        enableEdgeToEdge()
        setContent {
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val colorTheme by viewModel.colorTheme.collectAsStateWithLifecycle()
            val isSystemDark = isSystemInDarkTheme()
            
            val isDarkTheme = when (themeMode) {
                "light" -> false
                "dark" -> true
                else -> isSystemDark
            }
            
            LaunchedEffect(themeMode, colorTheme, isSystemDark) {
                val isDark = when (themeMode) {
                    "light" -> false
                    "dark" -> true
                    else -> isSystemDark
                }
                
                val (goldMain, goldLight) = when (colorTheme) {
                    "blue" -> Pair(Color(0xFF2980B9), Color(0xFF5DADE2))
                    "green" -> Pair(Color(0xFF27AE60), Color(0xFF58D68D))
                    "purple" -> Pair(Color(0xFF8E44AD), Color(0xFFBB8FCE))
                    "red" -> Pair(Color(0xFFE74C3C), Color(0xFFF1948A))
                    else -> Pair(Color(0xFFD4AF37), Color(0xFFF0D060))
                }
                
                ThemeGold = goldMain
                ThemeGoldLight = goldLight
                
                if (isDark) {
                    DarkBackground = Color(0xFF090909)
                    DarkSurface = Color(0xFF141414)
                    DarkSurfaceElevated = Color(0xFF1E1E1E)
                    TextLight = Color(0xFFF1EADF)
                    TextMuted = Color(0xFFA59E8E)
                } else {
                    DarkBackground = Color(0xFFF7F6F3)
                    DarkSurface = Color(0xFFFFFFFF)
                    DarkSurfaceElevated = Color(0xFFEDEDEA)
                    TextLight = Color(0xFF1B1A18)
                    TextMuted = Color(0xFF6E6A60)
                }
            }

            val appLanguage by viewModel.appLanguage.collectAsStateWithLifecycle()
            val isEn = appLanguage == "en"
            val layoutDir = if (isEn) LayoutDirection.Ltr else LayoutDirection.Rtl

            MyApplicationTheme(darkTheme = isDarkTheme) {
                // Force layout direction appropriate for the chosen language
                CompositionLocalProvider(
                    LocalLayoutDirection provides layoutDir,
                    LocalIsEnglish provides isEn
                ) {
                    Scaffold(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DarkBackground)
                    ) { innerPadding ->
                        MainScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MainScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val showCelebration by viewModel.showCelebrationDialog.collectAsStateWithLifecycle()
    val lastEarnedXP by viewModel.lastEarnedXP.collectAsStateWithLifecycle()
    val userStreak by viewModel.userStreak.collectAsStateWithLifecycle()
    val appLanguage by viewModel.appLanguage.collectAsStateWithLifecycle()
    val isEn = appLanguage == "en"

    var selectedDetailWord by remember { mutableStateOf<VocabularyWord?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .drawBehind {
                // Draw delicate ambient gold and red background glows
                drawCircle(
                    color = ThemeRed.copy(alpha = 0.05f),
                    radius = size.width * 0.6f,
                    center = Offset(0f, size.height * 0.1f)
                )
                drawCircle(
                    color = ThemeGold.copy(alpha = 0.04f),
                    radius = size.width * 0.5f,
                    center = Offset(size.width, size.height * 0.8f)
                )
            }
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. TOP BAR STATUS (XP & STREAK DAYS)
            TopStatusBar(viewModel)

            // 2. ADMOB COMPANION BANNER SPOT (As requested, styled placeholder)
            AdMobBannerPlaceholder()

            // 3. SECURE CENTRAL SCREEN CONTENT
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (currentTab) {
                    AppTab.HOME -> HomeScreen(viewModel, onSwitchTab = { viewModel.switchTab(it) })
                    AppTab.VOCAB -> VocabularyScreen(viewModel, onWordClick = { selectedDetailWord = it })
                    AppTab.CONVERSATIONS -> ConversationsScreen(viewModel)
                    AppTab.AI -> AiAssistantScreen(viewModel)
                    AppTab.EXERCISES -> ExercisesScreen(viewModel)
                    AppTab.SETTINGS -> SettingsScreen(viewModel)
                }
            }

            // 4. BOTTOM TABS NAVIGATION ROW
            BottomTabsNavigation(
                activeTab = currentTab,
                isEn = isEn,
                onTabSelect = { viewModel.switchTab(it) }
            )
        }

        // --- OVERLAY: WORD DETAIL MODAL POPUP ---
        selectedDetailWord?.let { word ->
            val savedWordIds by viewModel.savedWordIds.collectAsStateWithLifecycle()
            val completedWordIds by viewModel.completedWordIds.collectAsStateWithLifecycle()
            
            WordDetailDialog(
                word = word,
                isSaved = savedWordIds.contains(word.id.toString()),
                isCompleted = completedWordIds.contains(word.id.toString()),
                onToggleSave = { viewModel.toggleSaveWord(word) },
                onToggleComplete = { viewModel.toggleCompleteWord(word) },
                onDismiss = { selectedDetailWord = null },
                onSpeak = { viewModel.speakChinese(word.hanzi) }
            )
        }

        // --- OVERLAY: SUCCESS PROGRESS UP CELEBRATION BOX ---
        if (showCelebration) {
            LevelUpCelebrationDialog(
                xpGained = lastEarnedXP,
                streak = userStreak,
                onDismiss = { viewModel.closeCelebration() }
            )
        }

        // --- OVERLAY: INTERSTITIAL AD POPUP WITH 5 SEC COUNTDOWN ---
        val showInterstitialAd by viewModel.showInterstitialAd.collectAsStateWithLifecycle()
        val context = androidx.compose.ui.platform.LocalContext.current
        val activity = context as? MainActivity

        LaunchedEffect(showInterstitialAd) {
            if (showInterstitialAd && activity != null) {
                activity.mInterstitialAd?.let { ad ->
                    try {
                        ad.show(activity)
                        activity.mInterstitialAd = null
                        activity.loadInterstitialAd() // Cache the next one
                        viewModel.dismissInterstitial() // Reset viewModel trigger immediately
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        if (showInterstitialAd && (activity == null || activity.mInterstitialAd == null)) {
            InterstitialAdOverlay(
                onDismiss = { viewModel.dismissInterstitial() }
            )
        }
    }
}

@Composable
fun TopStatusBar(viewModel: MainViewModel) {
    val userXP by viewModel.userXP.collectAsStateWithLifecycle()
    val userStreak by viewModel.userStreak.collectAsStateWithLifecycle()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .border(width = 1.dp, color = ThemeGold.copy(alpha = 0.15f))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "华语通",
                color = ThemeGold,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Start
            )
            Text(
                text = "تعلم الصينية",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Start
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // XP Badge
            Row(
                modifier = Modifier
                    .background(DarkSurfaceElevated, shape = RoundedCornerShape(20.dp))
                    .border(width = 1.dp, color = ThemeGold.copy(alpha = 0.25f), shape = RoundedCornerShape(20.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(text = "⭐", fontSize = 12.sp)
                Text(
                    text = "$userXP XP",
                    color = ThemeGoldLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            // Days Streak Badge
            Row(
                modifier = Modifier
                    .background(DarkSurfaceElevated, shape = RoundedCornerShape(20.dp))
                    .border(width = 1.dp, color = ThemeGold.copy(alpha = 0.25f), shape = RoundedCornerShape(20.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(text = "🔥", fontSize = 12.sp)
                Text(
                    text = "$userStreak أيام",
                    color = ThemeGoldLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

@Composable
fun AdMobBannerPlaceholder() {
    var isAdLoaded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .background(DarkSurface),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (isAdLoaded) 50.dp else 0.dp),
            factory = { ctx ->
                AdView(ctx).apply {
                    setAdSize(AdSize.BANNER)
                    val adUnitIdVal = AppAdConfig.ADMOB_BANNER_AD_ID.ifEmpty { "ca-app-pub-9154986745650992/7903493015" }
                    adUnitId = adUnitIdVal
                    adListener = object : com.google.android.gms.ads.AdListener() {
                        override fun onAdLoaded() {
                            isAdLoaded = true
                        }
                        override fun onAdFailedToLoad(loadAdError: com.google.android.gms.ads.LoadAdError) {
                            isAdLoaded = false
                        }
                    }
                    try {
                        loadAd(AdRequest.Builder().build())
                    } catch (e: Exception) {
                        e.printStackTrace()
                        isAdLoaded = false
                    }
                }
            },
            update = { adView -> }
        )

        if (!isAdLoaded) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                ThemeRed.copy(alpha = 0.1f),
                                ThemeGold.copy(alpha = 0.08f)
                            )
                        )
                    )
                    .drawBehind {
                        val strokeWidth = 1.dp.toPx()
                        val dashLength = 10f
                        // Top border dash line
                        var x = 0f
                        while (x < size.width) {
                            drawLine(
                                color = ThemeGold.copy(alpha = 0.4f),
                                start = Offset(x, 0f),
                                end = Offset(x + dashLength, 0f),
                                strokeWidth = strokeWidth
                            )
                            x += dashLength * 2
                        }
                        // Bottom border dash line
                        x = 0f
                        while (x < size.width) {
                            drawLine(
                                color = ThemeGold.copy(alpha = 0.4f),
                                start = Offset(x, size.height),
                                end = Offset(x + dashLength, size.height),
                                strokeWidth = strokeWidth
                            )
                            x += dashLength * 2
                        }
                    }
                    .padding(vertical = 12.dp, horizontal = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "مساحة إعلانية نشطة • ADMOB BANNER AD",
                        color = ThemeGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "جاري التحميل",
                        modifier = Modifier
                            .background(ThemeGold, shape = RoundedCornerShape(3.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                        color = Color.Black,
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "جاري الاتصال بخوادم الإعلانات لتحميل البنر التفاعلي... يمكنك دمج معرّف AdMob الخاص بك بسهولة.",
                    color = TextMuted,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun BottomTabsNavigation(activeTab: AppTab, isEn: Boolean, onTabSelect: (AppTab) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .border(width = 1.dp, color = ThemeGold.copy(alpha = 0.15f))
            .navigationBarsPadding() // Avoid overlay on gesture bottom bars
            .height(65.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BottomNavItem(tab = AppTab.HOME, activeTab = activeTab, emoji = "🏠", title = tr("الرئيسية", isEn), onTabSelect, modifier = Modifier.testTag("nav_home"))
        BottomNavItem(tab = AppTab.VOCAB, activeTab = activeTab, emoji = "🀄", title = tr("القاموس", isEn), onTabSelect, modifier = Modifier.testTag("nav_vocab"))
        BottomNavItem(tab = AppTab.CONVERSATIONS, activeTab = activeTab, emoji = "💬", title = tr("الحوارات", isEn), onTabSelect, modifier = Modifier.testTag("nav_conversations"))
        BottomNavItem(tab = AppTab.AI, activeTab = activeTab, emoji = "🤖", title = tr("المساعد", isEn), onTabSelect, modifier = Modifier.testTag("nav_ai"))
        BottomNavItem(tab = AppTab.EXERCISES, activeTab = activeTab, emoji = "🎯", title = tr("التمارين", isEn), onTabSelect, modifier = Modifier.testTag("nav_exercises"))
        BottomNavItem(tab = AppTab.SETTINGS, activeTab = activeTab, emoji = "👤", title = tr("المستخدم", isEn), onTabSelect, modifier = Modifier.testTag("nav_profile"))
    }
}

@Composable
fun RowScope.BottomNavItem(
    tab: AppTab,
    activeTab: AppTab,
    emoji: String,
    title: String,
    onTabSelect: (AppTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val isActive = activeTab == tab
    Column(
        modifier = modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable { onTabSelect(tab) }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = emoji,
            fontSize = 20.sp,
            color = if (isActive) ThemeGoldLight else TextMuted
        )
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Bold,
            color = if (isActive) ThemeGoldLight else TextMuted
        )
    }
}

// --- TAB 1: HOME ---
@Composable
fun HomeScreen(viewModel: MainViewModel, onSwitchTab: (AppTab) -> Unit) {
    val appLanguage by viewModel.appLanguage.collectAsStateWithLifecycle()
    val isEn = appLanguage == "en"
    val dailyWord by viewModel.dailyWord.collectAsStateWithLifecycle()
    val allWords by viewModel.allAvailableWords.collectAsStateWithLifecycle()
    val completedWordIds by viewModel.completedWordIds.collectAsStateWithLifecycle()
    val savedWordIds by viewModel.savedWordIds.collectAsStateWithLifecycle()
    val userXP by viewModel.userXP.collectAsStateWithLifecycle()
    val userStreak by viewModel.userStreak.collectAsStateWithLifecycle()

    val totalWordsCount = allWords.size
    val completedCount = completedWordIds.size
    val savedCount = savedWordIds.size

    val levelCounts = remember(allWords, completedWordIds) {
        learningLevelsList.associate { level ->
            val levelWords = allWords.filter { it.category == level.category }
            val completedInLvlCount = levelWords.count { completedWordIds.contains(it.id.toString()) }
            level.category to Pair(completedInLvlCount, levelWords.size)
        }
    }

    val userLevelNum = when {
        userXP < 100 -> 1
        userXP < 250 -> 2
        userXP < 500 -> 3
        userXP < 800 -> 4
        userXP < 1200 -> 5
        else -> 6
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. HERO WELCOME & BRAND
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = tr("أهلاً بك في هواة هويو تونغ!", isEn) + " 🚀",
                        color = ThemeGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = tr("هنا نوفر لك تجربة تعليمية فائقة وفريدة لرحلتك الصينية الحديثة.", isEn),
                        color = TextLight,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onSwitchTab(AppTab.AI) },
                            colors = ButtonDefaults.buttonColors(containerColor = ThemeRed),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = tr("المساعد", isEn) + " 🤖", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { onSwitchTab(AppTab.SETTINGS) },
                            border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.4f)),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ThemeGold)
                        ) {
                            Text(text = tr("المستخدم", isEn) + " 👤", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. DYNAMIC PROGRESS & STATS DASHBOARD
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "📊 لوحة مؤشرات تقدمك الحالي",
                        color = ThemeGoldLight,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )

                    // Grid stats items layout (Manual Row mapping)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // XP Card
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(DarkSurfaceElevated, shape = RoundedCornerShape(10.dp))
                                .border(BorderStroke(1.dp, ThemeGold.copy(alpha = 0.1f)), shape = RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "💎 رصيد XP", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(text = "$userXP", color = ThemeGoldLight, fontSize = 16.sp, fontWeight = FontWeight.Black)
                        }

                        // Streak Card
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(DarkSurfaceElevated, shape = RoundedCornerShape(10.dp))
                                .border(BorderStroke(1.dp, ThemeRed.copy(alpha = 0.1f)), shape = RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "🔥 يوم متواصل", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(text = "$userStreak", color = ThemeRedLighterColor, fontSize = 16.sp, fontWeight = FontWeight.Black)
                        }

                        // Completed Card
                        Column(
                            modifier = Modifier
                                .weight(1.2f)
                                .background(DarkSurfaceElevated, shape = RoundedCornerShape(10.dp))
                                .border(BorderStroke(1.dp, Color(0xFF4CAF50).copy(alpha = 0.1f)), shape = RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "✅ رموز مكتملة", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(text = "$completedCount / $totalWordsCount", color = Color(0xFF81C784), fontSize = 15.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    // Global Vocabulary Mastery percentage bar indicator
                    val globalProgress = if (totalWordsCount > 0) completedCount.toFloat() / totalWordsCount else 0.0f
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "نسبة تمكّنك من كامل القاموس الصيني:", color = TextLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "${(globalProgress * 100).toInt()}%", color = ThemeGold, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        LinearProgressIndicator(
                            progress = globalProgress,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = ThemeGold,
                            trackColor = Color.White.copy(alpha = 0.08f)
                        )
                    }
                }
            }
        }

        // 3. WORD OF THE DAY
        item {
            Text(
                text = "📅 كلمة اليوم العشوائية",
                color = TextLight,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black
            )
        }

        item {
            dailyWord?.let { word ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.speakChinese(word.hanzi) },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { viewModel.speakChinese(word.hanzi) },
                            modifier = Modifier.background(DarkSurfaceElevated, shape = CircleShape)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play Sound", tint = ThemeGold)
                        }
                        Column(
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = word.hanzi,
                                color = TextLight,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = word.pinyin,
                                color = ThemeGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = word.arabic,
                                color = TextMuted,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 4. PROGRESSIVE LEARNING MAP ROADMAP (Timeline)
        item {
            Text(
                text = "🗺️ خريطة طريق مستويات التعلم (خطوة بخطوة)",
                color = TextLight,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(learningLevelsList, key = { it.number }) { level ->
            val counts = levelCounts[level.category] ?: Pair(0, 0)
            val completedInLvlCount = counts.first
            val totalInLvlCount = counts.second

            LevelStepCard(
                level = level,
                currentXP = userXP,
                totalCount = totalInLvlCount,
                completedCount = completedInLvlCount,
                onStartLearning = {
                    viewModel.selectedVocabFilter.value = level.category
                    viewModel.switchTab(AppTab.VOCAB)
                },
                onStartQuiz = {
                    viewModel.startQuizForCategory(level.category, null)
                    viewModel.switchTab(AppTab.EXERCISES)
                }
            )
        }

        // 5. QUICK DIRECTORY WIDGETS
        item {
            Text(
                text = "📈 روابط التعلم والتحكم السريعة",
                color = TextLight,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSwitchTab(AppTab.VOCAB) },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(text = "🀄", fontSize = 28.sp)
                        Text(text = "القاموس الشامل", color = TextLight, fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Text(text = "تصفح الكلمات مع النطق والبحث الذكي.", color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp)
                        Text(
                            text = "300+ كلمة مبرمجة",
                            modifier = Modifier
                                .background(ThemeGold.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            color = ThemeGoldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSwitchTab(AppTab.EXERCISES) },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(text = "🧠", fontSize = 28.sp)
                        Text(text = "تحديات يومية", color = TextLight, fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Text(text = "بطاقات الذاكرة السريعة واختبارات المعرفة.", color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp)
                        Text(
                            text = "XP مضاعف مجاني",
                            modifier = Modifier
                                .background(ThemeGold.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            color = ThemeGoldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
        
        item {
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
fun LevelStepCard(
    level: LearningLevel,
    currentXP: Int,
    totalCount: Int,
    completedCount: Int,
    onStartLearning: () -> Unit,
    onStartQuiz: () -> Unit
) {
    val isUnlocked = currentXP >= level.requiredXP
    val progress = if (totalCount > 0) completedCount.toFloat() / totalCount else 0.0f

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnlocked) DarkSurface else DarkBackground.copy(alpha = 0.5f)
        ),
        border = BorderStroke(
            width = 1.dp, 
            color = if (isUnlocked) {
                if (progress == 1f) Color(0xFF4CAF50).copy(alpha = 0.6f)
                else ThemeGold.copy(alpha = 0.25f)
            } else Color.White.copy(alpha = 0.04f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Left Node Avatar Milestone representation
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.width(55.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(
                            color = if (isUnlocked) {
                                if (progress == 1f) Color(0xFF4CAF50).copy(alpha = 0.12f)
                                else ThemeGold.copy(alpha = 0.08f)
                            } else Color.White.copy(alpha = 0.04f),
                            shape = CircleShape
                        )
                        .border(
                            width = 2.dp,
                            color = if (isUnlocked) {
                                if (progress == 1f) Color(0xFF4CAF50)
                                else ThemeGold
                            } else Color.White.copy(alpha = 0.15f),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isUnlocked) {
                        Text(text = level.icon, fontSize = 21.sp)
                    } else {
                        Text(text = "🔒", fontSize = 16.sp)
                    }
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = "مستوى ${level.number}",
                    color = if (isUnlocked) ThemeGoldLight else TextMuted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            // Right Level Details
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = level.title,
                        color = if (isUnlocked) TextLight else TextMuted,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                    
                    if (!isUnlocked) {
                        Surface(
                            color = ThemeRed.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "يفتح بـ ${level.requiredXP} XP",
                                color = ThemeRedLighterColor,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    } else if (progress == 1f && totalCount > 0) {
                        Surface(
                            color = Color(0xFF4CAF50).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "مكتمل بنجاح! 🎉",
                                color = Color(0xFF81C784),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                
                Text(
                    text = level.description,
                    color = if (isUnlocked) TextMuted else TextMuted.copy(alpha = 0.5f),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
                
                if (isUnlocked && totalCount > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الإنجاز: $completedCount / $totalCount كلمة",
                            color = ThemeGoldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${(progress * 100).toInt()}%",
                            color = ThemeGoldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    
                    LinearProgressIndicator(
                        progress = progress,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = if (progress == 1f) Color(0xFF4CAF50) else ThemeGold,
                        trackColor = Color.White.copy(alpha = 0.08f)
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onStartLearning,
                            colors = ButtonDefaults.buttonColors(containerColor = ThemeGold),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text(text = "دراسة الرموز 📚", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        
                        OutlinedButton(
                            onClick = onStartQuiz,
                            border = BorderStroke(1.dp, ThemeRed.copy(alpha = 0.4f)),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ThemeRed),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text(text = "اختبار سريع 🎯", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// --- TAB 2: VOCABULARY SCREEN ---
@Composable
fun VocabularyScreen(viewModel: MainViewModel, onWordClick: (VocabularyWord) -> Unit) {
    val words by viewModel.filteredWords.collectAsStateWithLifecycle()
    val query by viewModel.vocabSearchQuery.collectAsStateWithLifecycle()
    val activeFilter by viewModel.selectedVocabFilter.collectAsStateWithLifecycle()
    val savedWordIds by viewModel.savedWordIds.collectAsStateWithLifecycle()
    val completedWordIds by viewModel.completedWordIds.collectAsStateWithLifecycle()

    val filters = listOf("الكل", "المحفوظة ❤️", "المكتملة ✅", "HSK 1", "HSK 2", "التحيات", "ضمائر", "العائلة", "أرقام", "أفعال", "طعام", "تجارة", "العلاقات")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "القاموس اللغوي الشامل 🀄",
            color = TextLight,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            text = "ابحث عن أي كلمة صينية، واستمع لنطقها الفوري بالنقر عليها، وتعرف على مستواها الأكاديمي المعتمد.",
            color = TextMuted,
            fontSize = 12.sp
        )

        // Search Input Bar
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.vocabSearchQuery.value = it },
            placeholder = { Text(text = "ابحث بالصينية، العربية، الإنجليزية أو بينيين...", color = TextMuted, fontSize = 13.sp) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("vocab_search_input"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextLight,
                unfocusedTextColor = TextLight,
                focusedBorderColor = ThemeGold,
                unfocusedBorderColor = ThemeGold.copy(alpha = 0.3f),
                focusedContainerColor = DarkSurface,
                unfocusedContainerColor = DarkSurface
            ),
            singleLine = true
        )

        // Horizontal Filters Scroll Bar
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filters, key = { it }) { f ->
                val isActive = f == activeFilter
                Box(
                    modifier = Modifier
                        .background(
                            color = if (isActive) ThemeGold else DarkSurface,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .border(
                            width = 1.dp,
                            color = if (isActive) ThemeGold else ThemeGold.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { viewModel.selectedVocabFilter.value = f }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = f,
                        color = if (isActive) Color.Black else ThemeGoldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        // Two-column grid list of cards
        if (words.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "لا توجد مصطلحات تنطبق عليها عبارة البحث الحالية.", color = TextMuted, fontSize = 13.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(words, key = { it.id }) { word ->
                    val isSaved = savedWordIds.contains(word.id.toString())
                    val isCompleted = completedWordIds.contains(word.id.toString())
                    
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onWordClick(word) },
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = BorderStroke(
                            width = 1.dp, 
                            color = if (isCompleted) Color(0xFF4CAF50).copy(alpha = 0.6f) else ThemeGold.copy(alpha = 0.15f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Box(modifier = Modifier.padding(12.dp)) {
                            // HSK Label on Top Corner
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .background(ThemeGold.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(text = "HSK ${word.level}", color = ThemeGold, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }

                            // Top End Row Containing Speaker & Bookmark / Complete
                            Row(
                                modifier = Modifier.align(Alignment.TopEnd),
                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Save/Heart icon
                                IconButton(
                                    onClick = { viewModel.toggleSaveWord(word) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Save Word",
                                        tint = if (isSaved) ThemeRed else TextMuted,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }

                                // Audio Speaker trigger
                                IconButton(
                                    onClick = { viewModel.speakChinese(word.hanzi) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Speak Word",
                                        tint = ThemeGoldLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 22.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(1.dp)
                            ) {
                                Text(
                                    text = word.hanzi,
                                    color = TextLight,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = word.pinyin,
                                    color = ThemeGoldLighterAndBrighter,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = word.arabic,
                                    color = TextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                
                                Spacer(modifier = Modifier.height(4.dp))
                                
                                // Completed Checkbox Toggle Ribbon inside the card bottom
                                Card(
                                    onClick = { viewModel.toggleCompleteWord(word) },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isCompleted) Color(0xFF4CAF50).copy(alpha = 0.15f) else Color.White.copy(alpha = 0.03f)
                                    ),
                                    border = BorderStroke(
                                        width = 1.dp,
                                        color = if (isCompleted) Color(0xFF4CAF50).copy(alpha = 0.4f) else Color.White.copy(alpha = 0.1f)
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth().height(24.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (isCompleted) "أكملت ✅" else "لم يكتمل ◽",
                                            color = if (isCompleted) Color(0xFF81C784) else TextMuted,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

val ThemeGoldLighterAndBrighter = Color(0xFFFBE48A)

// --- TAB 3: DIALOGUE CONVERSATIONS ---
@Composable
fun ConversationsScreen(viewModel: MainViewModel) {
    val dialogues by viewModel.filteredDialogues.collectAsStateWithLifecycle()
    val activeCategory by viewModel.selectedDialogueCategory.collectAsStateWithLifecycle()
    val selectedLines by viewModel.selectedDialogueLines.collectAsStateWithLifecycle()
    val selectedTitle by viewModel.selectedDialogueTitle.collectAsStateWithLifecycle()

    val categories = listOf(
        Pair("all", tr("كل الحوارات")),
        Pair("greetings", tr("👋 التعارف والتحية")),
        Pair("travel", tr("✈️ السفر والوجهات")),
        Pair("restaurant", tr("🍽️ المطعم والوجبات")),
        Pair("hotel", tr("🏨 الفندق والإقامة")),
        Pair("business", tr("🤝 التجارة والمساومة"))
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = tr("حوارات يومية تفاعلية 💬"),
            color = TextLight,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            text = tr("اختر تصنيف المواقف الحياتية الحقيقية للاستماع لنطق العبارات والتدرب عليها."),
            color = TextMuted,
            fontSize = 12.sp
        )

        // Category filtration tabs scroll
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories, key = { it.first }) { item ->
                val isActive = item.first == activeCategory
                Box(
                    modifier = Modifier
                        .background(
                            color = if (isActive) ThemeGold else DarkSurface,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .border(
                            width = 1.dp,
                            color = if (isActive) ThemeGold else ThemeGold.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable {
                            viewModel.selectedDialogueCategory.value = item.first
                            // Clear selections
                            viewModel.selectedDialogueLines.value = emptyList()
                            viewModel.selectedDialogueTitle.value = ""
                        }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = item.second,
                        color = if (isActive) Color.Black else TextLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Dialogue List on right
            LazyColumn(
                modifier = Modifier
                    .weight(0.45f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(dialogues, key = { d -> d.id }) { d ->
                    val isSelected = d.title == selectedTitle
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.loadDialogueLines(d) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) ThemeRed.copy(alpha = 0.15f) else DarkSurface
                        ),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (isSelected) ThemeRed else ThemeGold.copy(alpha = 0.15f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = d.title, color = TextLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = d.category.split(" ").last(), color = TextMuted, fontSize = 10.sp)
                                Text(
                                    text = d.level,
                                    color = ThemeGoldLighterAndBrighter,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }

            // Dialogue Chat Area on left
            Card(
                modifier = Modifier
                    .weight(0.55f)
                    .fillMaxHeight(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                if (selectedLines.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tr("اضغط على أي عنوان حوار لعرض المحادثة والعبارات بالنطق الصوتي."),
                            color = TextMuted,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Title header
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkSurfaceElevated)
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = selectedTitle, color = ThemeGold, fontSize = 13.sp, fontWeight = FontWeight.Black)
                        }

                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(selectedLines, key = { it.id }) { line ->
                                  val isA = line.speaker == "a"
                                  Column(
                                      modifier = Modifier
                                          .fillMaxWidth(),
                                      horizontalAlignment = if (isA) Alignment.Start else Alignment.End
                                  ) {
                                      Box(
                                          modifier = Modifier
                                              .fillMaxWidth(0.9f)
                                              .background(
                                                  color = if (isA) ThemeRed.copy(alpha = 0.08f) else ThemeGold.copy(alpha = 0.05f),
                                                  shape = RoundedCornerShape(12.dp)
                                              )
                                              .border(
                                                  width = 1.dp,
                                                  color = if (isA) ThemeRed.copy(alpha = 0.5f) else ThemeGold.copy(alpha = 0.3f),
                                                  shape = RoundedCornerShape(12.dp)
                                              )
                                              .clickable { viewModel.speakChinese(line.hanzi) }
                                              .padding(10.dp)
                                      ) {
                                          Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                              Text(text = line.hanzi, color = TextLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                              Text(text = line.pinyin, color = ThemeGoldLight, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                              Text(text = line.arabic, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                              Text(
                                                  text = tr("🔊 نقر للنطق"),
                                                  color = ThemeGoldLighterAndBrighter,
                                                  fontSize = 9.sp,
                                                  fontWeight = FontWeight.Bold,
                                                  modifier = Modifier.padding(top = 4.dp)
                                              )
                                          }
                                      }
                                  }
                              }
                        }
                    }
                }
            }
        }
    }
}

// --- TAB 4: AI ASSISTANT ---
@Composable
fun AiAssistantScreen(viewModel: MainViewModel) {
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    var inputQuery by remember { mutableStateOf("") }

    val listState = rememberLazyListState()

    // Scroll to the bottom when new message arrives
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "مساعد الذكاء الاصطناعي (Gemini) 🤖",
            color = TextLight,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            text = "اطرح أي سؤال لغوي عن الصينية، النبرات الأربعة (pinyin)، شرح القواعد، أو ترجمة حرة للمصطلحات الصعبة.",
            color = TextMuted,
            fontSize = 11.sp
        )

        // Chats Thread
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.Black, shape = RoundedCornerShape(16.dp))
                .border(width = 1.dp, color = ThemeGold.copy(alpha = 0.15f), shape = RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { msg ->
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = if (msg.isUser) Alignment.End else Alignment.Start
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .background(
                                color = if (msg.isUser) ThemeGold else DarkSurfaceElevated,
                                shape = if (msg.isUser) {
                                    RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 0.dp)
                                } else {
                                    RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 0.dp, bottomEnd = 16.dp)
                                }
                            )
                            .border(
                                width = 1.dp,
                                color = if (msg.isUser) ThemeGold else ThemeGold.copy(alpha = 0.15f),
                                shape = if (msg.isUser) {
                                    RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 0.dp)
                                } else {
                                    RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 0.dp, bottomEnd = 16.dp)
                                }
                            )
                            .padding(12.dp)
                    ) {
                        if (msg.isLoading) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(color = ThemeGold, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Text(text = "المعلم الذكي يقرأ ويفكر في إجابتك...", color = TextMuted, fontSize = 11.sp)
                            }
                        } else {
                            Text(
                                text = msg.content,
                                color = if (msg.isUser) Color.Black else TextLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }

        // Send Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputQuery,
                onValueChange = { inputQuery = it },
                placeholder = { Text(text = "اكتب سؤالك بالبينين، العربية أو الصينية...", color = TextMuted, fontSize = 12.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_chat_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextLight,
                    unfocusedTextColor = TextLight,
                    focusedBorderColor = ThemeGold,
                    unfocusedBorderColor = ThemeGold.copy(alpha = 0.3f),
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputQuery.isNotEmpty()) {
                            viewModel.sendAIChat(inputQuery)
                            inputQuery = ""
                        }
                    }
                )
            )

            Button(
                onClick = {
                    if (inputQuery.isNotEmpty()) {
                        viewModel.sendAIChat(inputQuery)
                        inputQuery = ""
                    }
                },
                modifier = Modifier.height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ThemeRed),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "إرسال", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// --- TAB 5: GAME EXERCISES ---
@Composable
fun ExercisesScreen(viewModel: MainViewModel) {
    val type by viewModel.currentExerciseType.collectAsStateWithLifecycle()
    val quiz by viewModel.quizState.collectAsStateWithLifecycle()
    val flashcard by viewModel.flashcardState.collectAsStateWithLifecycle()

    // Handle physical back button from Android device
    androidx.activity.compose.BackHandler(enabled = type != ExerciseType.NONE) {
        viewModel.currentExerciseType.value = ExerciseType.NONE
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "تحديات التمكين اللغوي 🎯",
                color = TextLight,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black
            )
            
            if (type != ExerciseType.NONE) {
                OutlinedButton(
                    onClick = { viewModel.currentExerciseType.value = ExerciseType.NONE },
                    border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ThemeGold),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text(text = "رجوع ↩️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        
        Text(
            text = "شحذ معرفتك بالرموز الصينية ونغماتها عبر بطاقات الذاكرة أو الاختبارات الفورية السريعة لكسب الـ XP والتقدم.",
            color = TextMuted,
            fontSize = 11.sp
        )

        // Selections row (Visible only when no exercise is active)
        if (type == ExerciseType.NONE) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.startQuiz() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = ThemeRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = "✍️ بدء اختبار", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Button(
                    onClick = { viewModel.startFlashcards() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                    border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = "🃏 بطاقات الذاكرة", color = ThemeGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            // Interactive session bonus card satisfying custom rewards replacement
            var isClaimedToday by remember { mutableStateOf(false) }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { 
                        if (!isClaimedToday) {
                            viewModel.addXP(35)
                            isClaimedToday = true
                        }
                    },
                colors = CardDefaults.cardColors(
                    containerColor = if (isClaimedToday) DarkSurface.copy(alpha = 0.5f) else DarkSurface
                ),
                border = BorderStroke(1.dp, if (isClaimedToday) Color(0xFF4CAF50).copy(alpha = 0.3f) else ThemeGold.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(0.8f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (isClaimedToday) "🎁 تم الحصول على المكافأة بنجاح" else "🎁 مكافأة التفاعل اليومي السريع",
                            color = if (isClaimedToday) Color(0xFF81C784) else ThemeGoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (isClaimedToday) "عد غداً أو أكمل التمارين لتنمية مهاراتك باستمرار!" else "اضغط للحصول على هدية الحضور والمواظبة اليومية المجانية! +35 XP",
                            color = TextLight,
                            fontSize = 11.sp
                        )
                    }
                    Text(
                        text = if (isClaimedToday) "✅" else "⚡",
                        fontSize = 32.sp,
                        modifier = Modifier.weight(0.2f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // ACTIVE MODES DRAWERS
        when (type) {
            ExerciseType.QUIZ -> QuizLayout(viewModel, quiz)
            ExerciseType.FLASHCARD -> FlashcardLayout(viewModel, flashcard)
            ExerciseType.NONE -> {
                DailyQuestsDashboard(viewModel)
            }
        }
    }
}

@Composable
fun QuizLayout(viewModel: MainViewModel, state: QuizState) {
    if (state.questions.isEmpty() || state.currentIndex >= state.questions.size) return
    val currentQuestion = state.questions[state.currentIndex]

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${tr("سؤال")} ${state.currentIndex + 1} / ${state.questions.size}",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "${tr("✓ صح:")} ${state.scoreCorrect}", color = Color(0xFF2ECC71), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${tr("✕ خطأ:")} ${state.scoreWrong}", color = ThemeRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ThemeGold.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                    .padding(vertical = 4.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tr("🏆 مكافأة الاختبار: +١٥ نقطة لكل صح + ١٥ مكافأة إكمال 💎"),
                    color = ThemeGoldLight,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Target Hanzi
            Text(
                text = currentQuestion.hanzi,
                color = ThemeGoldLight,
                fontSize = 38.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )
            Text(
                text = currentQuestion.pinyin,
                color = ThemeGoldLighterAndBrighter,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            // Dynamic Options Button list to pick
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                state.options.forEach { opt ->
                    val isSelected = state.selectedOption?.id == opt.id
                    val isCorrectValue = opt.id == currentQuestion.id

                    val bgTint = when {
                        state.isAnswered && isCorrectValue -> Color(0xFF2ECC71).copy(alpha = 0.15f)
                        state.isAnswered && isSelected && !isCorrectValue -> ThemeRed.copy(alpha = 0.15f)
                        else -> DarkSurfaceElevated
                    }

                    val borderTint = when {
                        state.isAnswered && isCorrectValue -> Color(0xFF2ECC71)
                        state.isAnswered && isSelected && !isCorrectValue -> ThemeRed
                        else -> ThemeGold.copy(alpha = 0.2f)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(bgTint, shape = RoundedCornerShape(10.dp))
                            .border(1.dp, borderTint, shape = RoundedCornerShape(10.dp))
                            .clickable(enabled = !state.isAnswered) { viewModel.answerQuiz(opt) }
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${opt.arabic} (${opt.english})",
                            color = TextLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            if (state.isAnswered) {
                Button(
                    onClick = { viewModel.nextQuizStep() },
                    modifier = Modifier.fillMaxWidth().height(38.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ThemeGold),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(text = tr("السؤال التالي ➡️"), color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun FlashcardLayout(viewModel: MainViewModel, state: FlashcardState) {
    if (state.cards.isEmpty() || state.currentIndex >= state.cards.size) return
    val currentCard = state.cards[state.currentIndex]

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "${tr("بطاقة")} ${state.currentIndex + 1} / ${state.cards.size}",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ThemeGold.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                    .padding(vertical = 4.dp, horizontal = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tr("🃏 بطاقة الذاكرة: +١٠ نقاط لكل كارت معروف + ١٥ مكافأة إكمال 💎"),
                    color = ThemeGoldLight,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Clickable flip canvas area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp)
                    .clickable { viewModel.flipFlashcard() },
                contentAlignment = Alignment.Center
            ) {
                if (!state.isFlipped) {
                    // Front side
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(text = currentCard.hanzi, color = ThemeGold, fontSize = 44.sp, fontWeight = FontWeight.Black)
                        Text(text = tr("انقر لقلب البطاقة وكشف المعنى"), color = TextMuted, fontSize = 10.sp)
                    }
                } else {
                    // Back side
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = currentCard.pinyin, color = ThemeGoldLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = tr("العربية: ") + currentCard.arabic, color = TextLight, fontSize = 18.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                        Text(text = "English: " + currentCard.english, color = TextMuted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }
                }
            }

            // Knew it? buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.answerFlashcard(false) },
                    modifier = Modifier.weight(1f).height(38.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ThemeRed),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(text = tr("لم أعرفها ✕"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }

                Button(
                    onClick = { viewModel.answerFlashcard(true) },
                    modifier = Modifier.weight(1f).height(38.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2ECC71)),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(text = tr("عرفتها ✓"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

// --- TAB 6: SETTINGS & PREFERENCES ---
@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val userXP by viewModel.userXP.collectAsStateWithLifecycle()
    val streak by viewModel.userStreak.collectAsStateWithLifecycle()
    val speed by viewModel.speechSpeed.collectAsStateWithLifecycle()
    val autoSpeak by viewModel.autoSpeak.collectAsStateWithLifecycle()
    val activeTheme by viewModel.themeMode.collectAsStateWithLifecycle()
    val appLanguage by viewModel.appLanguage.collectAsStateWithLifecycle()
    val isEn = appLanguage == "en"

    // Level calculator
    val level = when {
        userXP <= 150 -> 1
        userXP <= 400 -> 2
        userXP <= 800 -> 3
        userXP <= 1500 -> 4
        userXP <= 3000 -> 5
        else -> 6
    }
    val levelTitle = when (level) {
        1 -> tr("مبتدئ (HSK 1)")
        2 -> tr("مبتدئ متقدم (HSK 2)")
        3 -> tr("ابتدائي (HSK 3)")
        4 -> tr("متوسط (HSK 4)")
        5 -> tr("متوسط متكامل (HSK 5)")
        else -> tr("متقدم خبير (HSK 6)")
    }

    val maxXP = when (level) {
        1 -> 150
        2 -> 400
        3 -> 800
        4 -> 1500
        5 -> 3000
        else -> 99999
    }
    val previousMax = when (level) {
        1 -> 0
        2 -> 151
        3 -> 401
        4 -> 801
        5 -> 1501
        else -> 3001
    }

    val fraction = if (maxXP == 99999) 1f else {
        val range = maxXP - previousMax
        val progressed = userXP - previousMax
        (progressed.toFloat() / range.toFloat()).coerceIn(0f, 1f)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = tr("الإعدادات العامة", isEn) + " 👤",
                color = TextLight,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = tr("مستواك الحالي، رصيدك من النقاط، وإعدادات السرعة ونطق الحروف الصينية بدقة.", isEn),
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, ThemeGold),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .background(
                                    Brush.linearGradient(colors = listOf(ThemeRed, ThemeGold)),
                                    shape = CircleShape
                                )
                                .padding(2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🎓", fontSize = 24.sp)
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            Text(text = tr("مستكشف اللغة الذكي"), color = TextLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "${tr("المستوى")} $level • $levelTitle", color = ThemeGoldLight, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = tr("معدل الترقية للمستوى التالي:"), color = TextMuted, fontSize = 10.sp)
                            Text(text = "$userXP / $maxXP XP", color = ThemeGoldLight, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                        // Linear progress indicator
                        LinearProgressIndicator(
                            progress = { fraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = ThemeGold,
                            trackColor = Color.White.copy(alpha = 0.1f)
                        )
                    }

                    // Bottom stats cards row grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(DarkSurfaceElevated, shape = RoundedCornerShape(12.dp))
                                .border(1.dp, Color.White.copy(alpha = 0.05f), shape = RoundedCornerShape(12.dp))
                                .padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "⭐", fontSize = 20.sp)
                            Text(text = "$userXP", color = ThemeGold, fontWeight = FontWeight.Black, fontSize = 15.sp)
                            Text(text = tr("نقاط خبرة XP"), color = TextMuted, fontSize = 9.sp)
                        }

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(DarkSurfaceElevated, shape = RoundedCornerShape(12.dp))
                                .border(1.dp, Color.White.copy(alpha = 0.05f), shape = RoundedCornerShape(12.dp))
                                .padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "🔥", fontSize = 20.sp)
                            Text(text = "$streak", color = ThemeGoldLight, fontWeight = FontWeight.Black, fontSize = 15.sp)
                            Text(text = tr("سلسلة الأيام"), color = TextMuted, fontSize = 9.sp)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = tr("⚙️ إعدادات التحكم بالنطق والمظهر"),
                color = TextLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Checkbox auto speak
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = tr("نطق تلقائي فوري"), color = TextLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(text = tr("تشغيل الصوت بمجرد النقر وكشف كروت الذاكرة"), color = TextMuted, fontSize = 10.sp)
                        }
                        Checkbox(
                            checked = autoSpeak,
                            onCheckedChange = { viewModel.updateAutoSpeak(it) },
                            colors = CheckboxDefaults.colors(checkedColor = ThemeGold, uncheckedColor = ThemeGold.copy(alpha = 0.5f))
                        )
                    }

                    Divider(color = Color.White.copy(alpha = 0.06f))

                    // Theme Selection Row
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = tr("وضع مظهر التطبيق (الوضع الداكن / المضيء):"), color = TextLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val themeOptions = listOf(Pair("dark", tr("داكن 🌙")), Pair("light", tr("مضيء ☀️")), Pair("system", tr("تلقائي 📱")))
                            themeOptions.forEach { pair ->
                                val isSelected = pair.first == activeTheme
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            color = if (isSelected) ThemeGold.copy(alpha = 0.15f) else DarkSurfaceElevated,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) ThemeGold else ThemeGold.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.updateThemeMode(pair.first) }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = pair.second, color = ThemeGoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Divider(color = Color.White.copy(alpha = 0.06f))

                    // Language Selection Row
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = tr("تغيير لغة التطبيق", isEn) + " 🌐:",
                            color = TextLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val languageOptions = listOf(Pair("ar", "العربية 🇸🇦"), Pair("en", "English 🇺🇸"))
                            languageOptions.forEach { pair ->
                                val isSelected = pair.first == appLanguage
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            color = if (isSelected) ThemeGold.copy(alpha = 0.15f) else DarkSurfaceElevated,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) ThemeGold else ThemeGold.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.updateAppLanguage(pair.first) }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = pair.second,
                                        color = ThemeGoldLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Divider(color = Color.White.copy(alpha = 0.06f))

                    // Color Accent Selection Row
                    val activeColorTheme by viewModel.colorTheme.collectAsStateWithLifecycle()
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = tr("تخصيص لون هوية التطبيق المميز 🎨:"), color = TextLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val colorOptions = listOf(
                                Triple("gold", tr("ذهبي 👑"), Color(0xFFD4AF37)),
                                Triple("blue", tr("أزرق 💎"), Color(0xFF2980B9)),
                                Triple("green", tr("أخضر 🌿"), Color(0xFF27AE60)),
                                Triple("purple", tr("بنفسجي 🔮"), Color(0xFF8E44AD)),
                                Triple("red", tr("أحمر 🍁"), Color(0xFFE74C3C))
                            )
                            colorOptions.forEach { triple ->
                                val isSelected = triple.first == activeColorTheme
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            color = if (isSelected) triple.third.copy(alpha = 0.15f) else DarkSurfaceElevated,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) triple.third else triple.third.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.updateColorTheme(triple.first) }
                                        .padding(vertical = 8.dp, horizontal = 2.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = triple.second, 
                                        color = if (isSelected) triple.third else TextLight, 
                                        fontSize = 9.sp, 
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Divider(color = Color.White.copy(alpha = 0.06f))

                    // Speech Speed selection buttons
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = tr("سرعة النطق الصوتي للدروس الحالية:"), color = TextLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val velocities = listOf(Pair(0.75f, tr("بطيء 🐢")), Pair(1.0f, tr("عادي 👤")), Pair(1.25f, tr("سريع ⚡")))
                            velocities.forEach { pair ->
                                val isSelected = pair.first == speed
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            color = if (isSelected) ThemeGold.copy(alpha = 0.15f) else DarkSurfaceElevated,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) ThemeGold else ThemeGold.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.updateSpeechSpeed(pair.first) }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = pair.second, color = ThemeGoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Divider(color = Color.White.copy(alpha = 0.06f))

                    // Reset button
                    var showResetConfirmation by remember { mutableStateOf(false) }
                    
                    Button(
                        onClick = { showResetConfirmation = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = ThemeRed.copy(alpha = 0.15f)),
                        border = BorderStroke(1.dp, ThemeRed.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = tr("تصفير النقاط وبدء التعلم من جديد 🔄"), color = ThemeRedLighterColor, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    if (showResetConfirmation) {
                        AlertDialog(
                            onDismissRequest = { showResetConfirmation = false },
                            title = {
                                Text(
                                    text = tr("تنبيه هام ومؤكد ⚠️"),
                                    color = ThemeRedLighterColor,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            },
                            text = {
                                Text(
                                    text = tr("هل أنت متأكد تماماً من رغبتك في تصفير وإعادة تعيين كافة تقدمك الحالي، بما في ذلك نقاط الـ XP، والكلمات المكتملة والمفضلة المحفوظة ومختلف التفضيلات المخصصة؟ لا يمكن التراجع عن هذا الإجراء أبداً!"),
                                    color = TextLight,
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        viewModel.resetProgress()
                                        showResetConfirmation = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ThemeRed)
                                ) {
                                    Text(text = tr("نعم، تصفير الآن ⚠️"), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            },
                            dismissButton = {
                                OutlinedButton(
                                    onClick = { showResetConfirmation = false },
                                    border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.5f))
                                ) {
                                    Text(text = tr("إلغاء وتراجع"), color = ThemeGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            },
                            containerColor = DarkSurface,
                            tonalElevation = 6.dp
                        )
                    }
                }
            }
        }
    }
}

val ThemeRedLighterColor = Color(0xFFFF8575)

// --- WORD DETAILS DIALOG ---
@Composable
fun WordDetailDialog(
    word: VocabularyWord,
    isSaved: Boolean,
    isCompleted: Boolean,
    onToggleSave: () -> Unit,
    onToggleComplete: () -> Unit,
    onDismiss: () -> Unit,
    onSpeak: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {},
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = word.hanzi,
                    color = ThemeGold,
                    fontSize = 62.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = word.pinyin,
                    color = ThemeGoldLight,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = tr("العربية: ") + word.arabic,
                    color = TextLight,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "English: ${word.english}",
                    color = TextMuted,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )

                // Grid stats details
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(DarkSurfaceElevated, shape = RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = tr("المستوى"), color = TextMuted, fontSize = 9.sp)
                        Text(text = "HSK ${word.level}", color = TextLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(DarkSurfaceElevated, shape = RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = tr("الفئة"), color = TextMuted, fontSize = 9.sp)
                        Text(text = word.category, color = TextLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Badge for learning XP
                Surface(
                    color = ThemeGold.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, ThemeGold.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "💎", fontSize = 14.sp)
                        Text(
                            text = tr("مكافأة التعلم المباشر: +10 XP"),
                            color = ThemeGoldLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Speak Button
                    Button(
                        onClick = onSpeak,
                        modifier = Modifier.weight(1.2f),
                        colors = ButtonDefaults.buttonColors(containerColor = ThemeGold),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = tr("🔊 نطق الكلمة"), color = Color.Black, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }

                    // Save (Heart) Toggle Button
                    Button(
                        onClick = onToggleSave,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSaved) ThemeRed else DarkSurfaceElevated
                        ),
                        border = BorderStroke(1.dp, if (isSaved) ThemeRed else ThemeGold.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isSaved) tr("❤️ حفظ") else tr("🤍 حفظ"),
                            color = if (isSaved) Color.White else ThemeGoldLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Complete Toggle Button
                    Button(
                        onClick = onToggleComplete,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCompleted) Color(0xFF4CAF50) else DarkSurfaceElevated
                        ),
                        border = BorderStroke(1.dp, if (isCompleted) Color(0xFF4CAF50) else ThemeGold.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isCompleted) tr("✅ أكملت") else tr("◽ أكملت"),
                            color = if (isCompleted) Color.White else ThemeGoldLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Close Button
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
                ) {
                    Text(text = tr("إغلاق النافذة"), color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        containerColor = DarkSurface,
        shape = RoundedCornerShape(20.dp),
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.padding(horizontal = 24.dp)
    )
}

// --- CELEBRATION PROGRESS POPUP ---
@Composable
fun LevelUpCelebrationDialog(
    xpGained: Int,
    streak: Int,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {},
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "🎉🥇",
                    fontSize = 54.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = tr("أحسنت صنعاً! 恭喜"),
                    color = ThemeGold,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = tr("لقد أكملت الجولة بنجاح وحققت أهدافك اللغوية لليوم وتم توثيق النتيجة وزيادة رصيد خبرتك."),
                    color = TextLight,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(DarkSurfaceElevated, shape = RoundedCornerShape(12.dp))
                            .padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "+$xpGained", color = ThemeGold, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text(text = tr("XP نقاط خبرة"), color = TextMuted, fontSize = 9.sp)
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(DarkSurfaceElevated, shape = RoundedCornerShape(12.dp))
                            .padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🔥 +1", color = ThemeGoldLight, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text(text = tr("أيام متتالية"), color = TextMuted, fontSize = 9.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ThemeGold),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = tr("استلام المكافأة 💎"), color = Color.Black, fontWeight = FontWeight.Black)
                }
            }
        },
        containerColor = DarkSurface,
        shape = RoundedCornerShape(20.dp),
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.padding(horizontal = 24.dp)
    )
}

@Composable
fun InterstitialAdOverlay(onDismiss: () -> Unit) {
    var secondsRemaining by remember { mutableStateOf(5) }
    LaunchedEffect(Unit) {
        while (secondsRemaining > 0) {
            kotlinx.coroutines.delay(1000L)
            secondsRemaining--
        }
    }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = {
            if (secondsRemaining <= 0) {
                onDismiss()
            }
        },
        properties = androidx.compose.ui.window.DialogProperties(
            dismissOnBackPress = secondsRemaining <= 0,
            dismissOnClickOutside = secondsRemaining <= 0,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.92f))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .widthIn(max = 500.dp)
                    .border(1.dp, ThemeGold.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = ThemeRed.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = tr("إعلان ممول"),
                                color = ThemeRed,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(
                            onClick = { if (secondsRemaining == 0) onDismiss() },
                            enabled = secondsRemaining == 0
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = tr("إغلاق الإعلان"),
                                tint = if (secondsRemaining == 0) androidx.compose.ui.graphics.Color.White else androidx.compose.ui.graphics.Color.Gray
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(DarkBackground, RoundedCornerShape(12.dp))
                            .border(1.dp, ThemeGold.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                tint = ThemeGold,
                                contentDescription = null,
                                modifier = Modifier.size(52.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "HuayuTong Pro",
                                color = ThemeGold,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = tr("تطبيق حوارات وكلمات الصينية رقم ١"),
                                color = androidx.compose.ui.graphics.Color.LightGray,
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = tr("ترقية العضوية للتخلص من الإعلانات تماماً!"),
                        color = androidx.compose.ui.graphics.Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    if (secondsRemaining > 0) {
                        Text(
                            text = "${tr("تخطي خلال ")} ${secondsRemaining}..",
                            color = ThemeGoldLight,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = ThemeGold),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = tr("تخطي الإعلان ✕"),
                                color = DarkBackground,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DailyQuestsDashboard(viewModel: MainViewModel) {
    val savedSet by viewModel.savedWordIds.collectAsStateWithLifecycle()
    val completedSet by viewModel.completedWordIds.collectAsStateWithLifecycle()
    val userXP by viewModel.userXP.collectAsStateWithLifecycle()
    val userStreak by viewModel.userStreak.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()

    val totalSaved = savedSet.size
    val totalCompleted = completedSet.size
    val totalChats = if (chatMessages.size > 1) chatMessages.size - 1 else 0

    val questsList = listOf(
        Triple("🌟 مفضلتي الذهبية الفردية", "قم بحفظ كلمة صينية واحدة على الأقل في قائمتك المفضلة.", totalSaved >= 1),
        Triple("🎓 التمكين الدراسي للرموز", "أنجز ٣ كلمات صينية وعلّم عليها كـ 'أكملت ✅' لترسيخ حفظها ونطقها.", totalCompleted >= 3),
        Triple("🔥 شعلة التعلم المتواصل", "نشّط الحساب وتأكد من بدء شعلة Streak التعلم.", userStreak >= 1),
        Triple("🤖 صديق الذكاء الاصطناعي", "اطرح سؤالاً واحداً على رفيق التعلم الذكي Gemini لتوضيح القواعد.", totalChats >= 1)
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurfaceElevated, RoundedCornerShape(16.dp))
            .border(BorderStroke(1.dp, ThemeGold.copy(alpha = 0.15f)), RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "🏆 مهام التحدي والإنجازات اليومية",
                color = ThemeGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = "مكافآت يومية نشطة",
                color = TextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Horizontal line separator
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Color.White.copy(alpha = 0.05f))
        )

        questsList.forEach { quest ->
            val (title, desc, isMet) = quest
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = if (isMet) Color(0xFF4CAF50).copy(alpha = 0.06f) else Color.White.copy(alpha = 0.02f),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .border(
                        width = 1.dp,
                        color = if (isMet) Color(0xFF4CAF50).copy(alpha = 0.3f) else Color.White.copy(alpha = 0.05f),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Done indicator circle
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .background(
                            color = if (isMet) Color(0xFF4CAF50) else Color.White.copy(alpha = 0.05f),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isMet) {
                        Text(text = "✓", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = title,
                        color = if (isMet) Color(0xFF81C784) else TextLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = desc,
                        color = TextMuted,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )
                }

                // Reward badge
                Box(
                    modifier = Modifier
                        .background(
                            color = if (isMet) Color(0xFF4CAF50).copy(alpha = 0.15f) else ThemeGold.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isMet) "مكتمل! 🎉" else "+30 XP",
                        color = if (isMet) Color(0xFF81C784) else ThemeGoldLight,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

