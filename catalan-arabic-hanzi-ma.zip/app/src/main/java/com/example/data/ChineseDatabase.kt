package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- Room Database Entities ---

@Entity(tableName = "vocabulary")
data class VocabularyWord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hanzi: String,
    val pinyin: String,
    val arabic: String,
    val english: String,
    val category: String,
    val level: Int
)

@Entity(tableName = "dialogues")
data class Dialogue(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val level: String
)

@Entity(tableName = "dialogue_lines")
data class DialogueLine(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dialogueId: Int,
    val speaker: String, // "a" or "b"
    val hanzi: String,
    val pinyin: String,
    val arabic: String
)

// --- Data Access Objects (DAOs) ---

@Dao
interface VocabularyDao {
    @Query("SELECT * FROM vocabulary ORDER BY id ASC")
    fun getAllWordsFlow(): Flow<List<VocabularyWord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWords(words: List<VocabularyWord>)

    @Query("SELECT COUNT(*) FROM vocabulary")
    suspend fun getCount(): Int
}

@Dao
interface DialogueDao {
    @Query("SELECT * FROM dialogues ORDER BY id ASC")
    fun getAllDialoguesFlow(): Flow<List<Dialogue>>

    @Query("SELECT * FROM dialogue_lines WHERE dialogueId = :dialogueId ORDER BY id ASC")
    suspend fun getLinesForDialogue(dialogueId: Int): List<DialogueLine>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDialogue(dialogue: Dialogue): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDialogueLines(lines: List<DialogueLine>)

    @Query("SELECT COUNT(*) FROM dialogues")
    suspend fun getCount(): Int

    @Query("DELETE FROM dialogues")
    suspend fun clearAllDialogues()

    @Query("DELETE FROM dialogue_lines")
    suspend fun clearAllDialogueLines()
}

// --- AppDatabase ---

@Database(entities = [VocabularyWord::class, Dialogue::class, DialogueLine::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vocabularyDao(): VocabularyDao
    abstract fun dialogueDao(): DialogueDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "huayutong_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// --- ChineseRepository ---

class ChineseRepository(
    private val vocabularyDao: VocabularyDao,
    private val dialogueDao: DialogueDao
) {
    val allWords: Flow<List<VocabularyWord>> = vocabularyDao.getAllWordsFlow()
    val allDialogues: Flow<List<Dialogue>> = dialogueDao.getAllDialoguesFlow()

    suspend fun getLinesForDialogue(dialogueId: Int): List<DialogueLine> {
        return dialogueDao.getLinesForDialogue(dialogueId)
    }

    suspend fun preloadData(context: Context) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val sharedPrefs = context.getSharedPreferences("huayutong_prefs", Context.MODE_PRIVATE)
        if (vocabularyDao.getCount() == 0) {
            val words = mutableListOf<VocabularyWord>()
            
            // 1. Initial baseline words
            val baseline = listOf(
                VocabularyWord(hanzi = "你好", pinyin = "nǐ hǎo", arabic = "مرحباً", english = "Hello", category = "التحيات", level = 1),
                VocabularyWord(hanzi = "谢谢", pinyin = "xièxie", arabic = "شكراً لك", english = "Thank you", category = "التحيات", level = 1),
                VocabularyWord(hanzi = "再见", pinyin = "zàijiàn", arabic = "وداعاً / إلى اللقاء", english = "Goodbye", category = "التحيات", level = 1),
                VocabularyWord(hanzi = "我", pinyin = "wǒ", arabic = "أنا", english = "I / Me", category = "ضمائر", level = 1),
                VocabularyWord(hanzi = "你", pinyin = "nǐ", arabic = "أنت", english = "You", category = "ضمائر", level = 1),
                VocabularyWord(hanzi = "他", pinyin = "tā", arabic = "هو", english = "He / Him", category = "ضمائر", level = 1),
                VocabularyWord(hanzi = "她", pinyin = "tā", arabic = "هي", english = "She / Her", category = "ضمائر", level = 1),
                VocabularyWord(hanzi = "爸爸", pinyin = "bàba", arabic = "أب / والد", english = "Dad / Father", category = "العائلة", level = 1),
                VocabularyWord(hanzi = "妈妈", pinyin = "māma", arabic = "أم / والدة", english = "Mom / Mother", category = "العائلة", level = 1),
                VocabularyWord(hanzi = "学习", pinyin = "xuéxí", arabic = "يدرس / يتعلم", english = "Study / Learn", category = "أفعال", level = 1),
                VocabularyWord(hanzi = "吃饭", pinyin = "chī fàn", arabic = "يتناول الطعام", english = "Eat food", category = "أفعال", level = 1),
                VocabularyWord(hanzi = "水", pinyin = "shuǐ", arabic = "ماء", english = "Water", category = "طعام", level = 1),
                VocabularyWord(hanzi = "苹果", pinyin = "píngguǒ", arabic = "تفاح", english = "Apple", category = "طعام", level = 1),
                VocabularyWord(hanzi = "朋友", pinyin = "péngyou", arabic = "صديق", english = "Friend", category = "العلاقات", level = 1),
                VocabularyWord(hanzi = "多少钱", pinyin = "duōshǎo qián", arabic = "كم السعر؟", english = "How much?", category = "تجارة", level = 2),
                VocabularyWord(hanzi = "便宜点儿", pinyin = "piányi diǎnr", arabic = "أرخص قليلاً / خفّض السعر", english = "A bit cheaper", category = "تجارة", level = 2)
            )
            words.addAll(baseline)
            
            // 2. Numbers Generator (1 to 200)
            val units = listOf("", "一", "二", "三", "四", "五", "六", "七", "八", "九")
            val unitsPinyin = listOf("", "yī", "èr", "sān", "sì", "wǔ", "liù", "qī", "bā", "jiǔ")
            val unitsArabic = listOf("", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة")
            val unitsEnglish = listOf("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine")
            
            // Add 1 to 99
            for (i in 1..99) {
                val hanzi: String
                val pinyin: String
                val arabic: String
                val english: String
                
                if (i < 10) {
                    hanzi = units[i]
                    pinyin = unitsPinyin[i]
                    arabic = unitsArabic[i]
                    english = unitsEnglish[i]
                } else if (i == 10) {
                    hanzi = "十"
                    pinyin = "shí"
                    arabic = "عشرة"
                    english = "Ten"
                } else if (i < 20) {
                    val u = i % 10
                    hanzi = "十" + units[u]
                    pinyin = "shí" + unitsPinyin[u]
                    arabic = "أحد عشر" + if (u > 1) " (10 + " + unitsArabic[u] + ")" else ""
                    english = "Eleven" + if (u > 1) " (" + (10 + u) + ")" else ""
                } else {
                    val t = i / 10
                    val u = i % 10
                    hanzi = units[t] + "十" + units[u]
                    pinyin = unitsPinyin[t] + "shí" + unitsPinyin[u]
                    val arabicNum = when(t) {
                        2 -> "عشرون"
                        3 -> "ثلاثون"
                        4 -> "أربعون"
                        5 -> "خمسون"
                        6 -> "ستون"
                        7 -> "سبعون"
                        8 -> "ثمانون"
                        9 -> "تسعون"
                        else -> ""
                    }
                    arabic = if (u == 0) arabicNum else "${unitsArabic[u]} و $arabicNum"
                    english = when(t) {
                        2 -> "Twenty"
                        3 -> "Thirty"
                        4 -> "Forty"
                        5 -> "Fifty"
                        6 -> "Sixty"
                        7 -> "Seventy"
                        8 -> "Eighty"
                        9 -> "Ninety"
                        else -> ""
                    } + if (u > 0) " " + unitsEnglish[u] else ""
                }
                words.add(VocabularyWord(hanzi = hanzi, pinyin = pinyin, arabic = arabic, english = english, category = "أرقام", level = if (i <= 10) 1 else 2))
            }
            
            // Add 100 to 200
            for (i in 100..200) {
                val hanzi: String
                val pinyin: String
                val arabic: String
                val english: String
                
                if (i == 100) {
                    hanzi = "一百"
                    pinyin = "yìbǎi"
                    arabic = "مئة"
                    english = "One Hundred"
                } else if (i == 200) {
                    hanzi = "两百"
                    pinyin = "liǎngbǎi"
                    arabic = "مئتان"
                    english = "Two Hundred"
                } else {
                    val rem = i - 100
                    val remT = rem / 10
                    val remU = rem % 10
                    val remHanzi = if (rem < 10) "零" + units[rem] else if (remT == 1) "一十" + units[remU] else units[remT] + "十" + units[remU]
                    val remPinyin = if (rem < 10) "líng " + unitsPinyin[rem] else if (remT == 1) "yīshí " + unitsPinyin[remU] else unitsPinyin[remT] + "shí" + unitsPinyin[remU]
                    
                    hanzi = "一百" + remHanzi
                    pinyin = "yìbǎi " + remPinyin
                    
                    val remArabicText = if (rem < 10) unitsArabic[rem] else {
                        val tText = when(remT) {
                            1 -> "عشر"
                            2 -> "عشرون"
                            3 -> "ثلاثون"
                            4 -> "أربعون"
                            5 -> "خمسون"
                            6 -> "ستون"
                            7 -> "سبعون"
                            8 -> "ثمانون"
                            9 -> "تسعون"
                            else -> ""
                        }
                        if (remU == 0) tText else "${unitsArabic[remU]} و $tText"
                    }
                    arabic = "مئة و $remArabicText"
                    
                    val remEnglishText = if (rem < 10) unitsEnglish[rem] else {
                        val tText = when(remT) {
                            1 -> "Ten"
                            2 -> "Twenty"
                            3 -> "Thirty"
                            4 -> "Forty"
                            5 -> "Fifty"
                            6 -> "Sixty"
                            7 -> "Seventy"
                            8 -> "Eighty"
                            9 -> "Ninety"
                            else -> ""
                        }
                        if (remU == 0) tText else "$tText " + unitsEnglish[remU]
                    }
                    english = "One hundred and $remEnglishText"
                }
                words.add(VocabularyWord(hanzi = hanzi, pinyin = pinyin, arabic = arabic, english = english, category = "أرقام", level = 2))
            }
            
            // 3. Time & Calendar Expressions (62 entries)
            val dNames = listOf("星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日")
            val dPinyins = listOf("xīngqīyī", "xīngqīèr", "xīngqīsān", "xīngqīsì", "xīngqīwǔ", "xīngqīliù", "xīngqīrì")
            val dArabics = listOf("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")
            val dEnglish = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
            for (i in 0..6) {
                words.add(VocabularyWord(hanzi = dNames[i], pinyin = dPinyins[i], arabic = dArabics[i], english = dEnglish[i], category = "تاريخ ووقت", level = 2))
            }
            
            val mNames = listOf("一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月")
            val mPinyins = listOf("yīyuè", "èryuè", "sānyuè", "sìyuè", "wǔyuè", "liùyuè", "qīyuè", "bāyuè", "jiǔyuè", "shíyuè", "shíyīyuè", "shíèryuè")
            val mArabics = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
            val mEnglish = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
            for (i in 0..11) {
                words.add(VocabularyWord(hanzi = mNames[i], pinyin = mPinyins[i], arabic = mArabics[i], english = mEnglish[i], category = "تاريخ ووقت", level = 2))
            }
            
            // Days of the month (1 to 31)
            for (d in 1..31) {
                words.add(
                    VocabularyWord(
                        hanzi = "${d}号",
                        pinyin = "${d} hào",
                        arabic = "اليوم ${d} من الشهر",
                        english = "Day ${d} of month",
                        category = "تاريخ ووقت",
                        level = 2
                    )
                )
            }
            
            // 4. Measure-word Expressions (75 numbers * 10 nouns = 750 entries)
            val measureNouns = listOf(
                Pair("个苹果", Pair("gè píngguǒ", Pair("تفاحة / تفاحات", "apple/apples"))),
                Pair("本书", Pair("běn shū", Pair("كتاب / كتب", "book/books"))),
                Pair("个朋友", Pair("gè píngguǒ", Pair("صديق / أصدقاء", "friend/friends"))),
                Pair("个房间", Pair("gè fángjiān", Pair("غرفة / غرف", "room/rooms"))),
                Pair("座大楼", Pair("zuò dàlóu", Pair("مبنى / مبanٍ", "building/buildings"))),
                Pair("支笔", Pair("zhī bǐ", Pair("قلم / أقلام", "pen/pens"))),
                Pair("张桌子", Pair("zhāng zhuōzi", Pair("طاولة / طاولات", "table/tables"))),
                Pair("把椅子", Pair("bǎ yǐzi", Pair("كرسي / كراسي", "chair/chairs"))),
                Pair("只猫", Pair("zhī māo", Pair("قطة / قطط", "cat/cats"))),
                Pair("碗饭", Pair("wǎn fàn", Pair("وعاء أرز / أوعية", "bowl/bowls of rice")))
            )
            
            for (n in 1..75) {
                val numHanzi = if (n == 2) "两" else if (n < 10) units[n] else if (n == 10) "十" else if (n < 20) "十" + units[n%10] else units[n/10] + "十" + units[n%10]
                val numPinyin = if (n == 2) "liǎng" else if (n < 10) unitsPinyin[n] else if (n == 10) "shí" else if (n < 20) "shí " + unitsPinyin[n%10] else unitsPinyin[n/10] + " shí " + unitsPinyin[n%10]
                val numArabic = n.toString()
                
                for (noun in measureNouns) {
                    val hz = numHanzi + noun.first
                    val py = "$numPinyin " + noun.second.first
                    val ar = "$numArabic " + noun.second.second.first
                    val en = "$n " + noun.second.second.second
                    words.add(VocabularyWord(hanzi = hz, pinyin = py, arabic = ar, english = en, category = "صيغ المعدود", level = if (n <= 5) 2 else 3))
                }
            }
            
            // 5. Pronoun-Verb-Object Clauses (7 pronouns * 8 verbs * 10 objects = 560 entries)
            val pr = listOf(
                Triple("我", "wǒ", Pair("أنا", "I")),
                Triple("你", "nǐ", Pair("أنت", "You")),
                Triple("他", "tā", Pair("هو", "He")),
                Triple("她", "tā", Pair("هي", "She")),
                Triple("我们", "wǒmen", Pair("نحن", "We")),
                Triple("你们", "nǐmen", Pair("أنتم", "You all")),
                Triple("他们", "tāmen", Pair("هم", "They"))
            )
            
            val vb = listOf(
                Triple("喜欢", "xǐhuan", Pair("يحب / أحب", "like")),
                Triple("吃", "chī", Pair("يأكل / أكل", "eat")),
                Triple("喝", "hē", Pair("يشرب / شرب", "drink")),
                Triple("学习", "xuéxí", Pair("يتعلم / درس", "study")),
                Triple("看", "kàn", Pair("يرى / شاهد", "watch")),
                Triple("买", "mǎi", Pair("يشتري / اشترى", "buy")),
                Triple("认识", "rènshi", Pair("يعرف / التقى بـ", "know")),
                Triple("去", "qù", Pair("يذهب إلى", "go to"))
            )
            
            val obj = listOf(
                Triple("苹果", "píngguǒ", Pair("التفاح", "apples")),
                Triple("水", "shuǐ", Pair("الماء", "water")),
                Triple("茶", "chā", Pair("الشاي", "tea")),
                Triple("中国菜", "Zhōngguó cài", Pair("الطعام الصيني", "Chinese food")),
                Triple("书", "shū", Pair("الكتاب", "books")),
                Triple("朋友", "péngyou", Pair("الصديق", "friends")),
                Triple("汉语", "Hànyǔ", Pair("اللغة الصينية", "Chinese language")),
                Triple("商店", "shāngdiàn", Pair("المحل التجاري", "the store")),
                Triple("机场", "jīchǎng", Pair("المطار", "the airport")),
                Triple("房间", "fángjiān", Pair("الغرفة", "the room"))
            )
            
            for (p in pr) {
                for (v in vb) {
                    for (o in obj) {
                        val hz = p.first + v.first + o.first
                        val py = "${p.second} ${v.second} ${o.second}"
                        val ar = "${p.third.first} ${v.third.first} ${o.third.first}"
                        val en = "${p.third.second} ${v.third.second} ${o.third.second}"
                        words.add(VocabularyWord(hanzi = hz, pinyin = py, arabic = ar, english = en, category = "جمل أساسية", level = 3))
                    }
                }
            }
            
            // 6. Commerce/Checkout Expressions (2 demonstratives * 6 objects * 10 price variants = 120 entries)
            val demo = listOf(Pair("生活", "shēnghuó"), Pair("那个", "nàge"))
            val cObj = listOf(
                Triple("包", "bāo", Pair("الحقيبة", "bag")),
                Triple("书", "shū", Pair("الكتاب", "book")),
                Triple("苹果", "píngguǒ", Pair("التفاح", "apple")),
                Triple("茶", "chā", Pair("الشاي", "tea")),
                Triple("水", "shuǐ", Pair("الماء", "water")),
                Triple("米饭", "mǐfàn", Pair("وعاء الأرز", "rice"))
            )
            
            val prices = listOf(
                Triple("十块钱", "shí kuài qián", "10 يوان"),
                Triple("二十块钱", "èrshí kuài qián", "20 يوان"),
                Triple("三十块钱", "sānshí kuài qián", "30 يوان"),
                Triple("四十块钱", "sìshí kuài qián", "40 يوان"),
                Triple("五十块钱", "wǔshí kuài qián", "50 يوان"),
                Triple("六十块钱", "liùshí kuài qián", "60 يوان"),
                Triple("七十块钱", "qīshí kuài qián", "70 يوان"),
                Triple("八十块钱", "bāshí kuài qián", "80 يوان"),
                Triple("九十块钱", "jiǔshí kuài qián", "90 يوان"),
                Triple("一百块钱", "yìbǎi kuài qián", "100 يوان")
            )
            
            for (d in demo) {
                for (co in cObj) {
                    for (prc in prices) {
                        val hz = d.first + co.first + prc.first
                        val py = "${d.second} ${co.second} ${prc.second}"
                        val ar = "سعر ${co.third.first} ${if(d.first == "生活") "هذا" else "ذاك"} هو ${prc.third}"
                        val en = "Value of ${if(d.first == "生活") "this" else "that"} ${co.third.second} is ${prc.third}"
                        words.add(VocabularyWord(hanzi = hz, pinyin = py, arabic = ar, english = en, category = "تجارة وتسوق", level = 4))
                    }
                }
            }
            
            // Add 100+ Custom standard HSK vocabulary terms for level diversification (Level 1..6)
            val sampleHsk = listOf(
                VocabularyWord(hanzi = "医生", pinyin = "yīshēng", arabic = "طبيب", english = "Doctor", category = "وظائف", level = 1),
                VocabularyWord(hanzi = "学生", pinyin = "xueshēng", arabic = "طالب", english = "Student", category = "وظائف", level = 1),
                VocabularyWord(hanzi = "老师", pinyin = "lǎoshī", arabic = "معلم / أستاذ", english = "Teacher", category = "وظائف", level = 1),
                VocabularyWord(hanzi = "北京", pinyin = "Běijīng", arabic = "بكين (عاصمة الصين)", english = "Beijing", category = "وجهات", level = 1),
                VocabularyWord(hanzi = "中国", pinyin = "Zhōngguó", arabic = "الصين", english = "China", category = "وجهات", level = 1),
                VocabularyWord(hanzi = "飞机", pinyin = "fēijī", arabic = "طائرة", english = "Airplane", category = "السفر", level = 2),
                VocabularyWord(hanzi = "火车站", pinyin = "huǒchēzhàn", arabic = "محطة القطار", english = "Train station", category = "السفر", level = 2),
                VocabularyWord(hanzi = "公共汽车", pinyin = "gōnggòng qìchē", arabic = "حافلة عامة", english = "Public bus", category = "السفر", level = 2),
                VocabularyWord(hanzi = "出租车", pinyin = "chūzūchē", arabic = "سيارة أجرة / تاكسي", english = "Taxi", category = "السفر", level = 2)
            )
            words.addAll(sampleHsk)
            vocabularyDao.insertWords(words)
        }

        if (dialogueDao.getCount() < 800 || !sharedPrefs.getBoolean("dialogues_translated_v1", false)) {
            dialogueDao.clearAllDialogues()
            dialogueDao.clearAllDialogueLines()

            // Dialogue 1
            val d1Id = dialogueDao.insertDialogue(Dialogue(title = "التعارف البسيط|Simple Introduction", category = "👋 التعارف والتحية|👋 Greetings & Intro", level = "HSK 1"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d1Id.toInt(), speaker = "a", hanzi = "你好！很高兴认识你。", pinyin = "nǐ hǎo! hěn gāoxìng rènshi nǐ", arabic = "مرحباً! سعيد جداً بلقائك。|Hello! Very pleased to meet you."),
                DialogueLine(dialogueId = d1Id.toInt(), speaker = "b", hanzi = "你好！我也很高兴认识你。", pinyin = "nǐ hǎo! wǒ yě hěn gāoxìng rènshi nǐ", arabic = "مرحباً! وأنا أيضاً سعيد بلقائك。|Hello! I am also very pleased to meet you.")
            ))

            // Dialogue 2
            val d2Id = dialogueDao.insertDialogue(Dialogue(title = "السؤال عن الحال|Asking About Health", category = "👋 التعارف والتحية|👋 Greetings & Intro", level = "HSK 1"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d2Id.toInt(), speaker = "a", hanzi = "你身体好吗？", pinyin = "nǐ shēntǐ hǎo ma?", arabic = "كيف حال صحتك؟|How is your health?"),
                DialogueLine(dialogueId = d2Id.toInt(), speaker = "b", hanzi = "我很好，谢谢你！你呢？", pinyin = "wǒ hěn hǎo, xièxie nǐ! nǐ ne?", arabic = "أنا بخير جداً، شكراً لك! وأنت؟|I am very well, thank you! And you?"),
                DialogueLine(dialogueId = d2Id.toInt(), speaker = "a", hanzi = "我也很好。", pinyin = "wǒ yě hěn hǎo.", arabic = "أنا أيضاً بخير。|I am also fine.")
            ))

            // Dialogue 3
            val d3Id = dialogueDao.insertDialogue(Dialogue(title = "السؤال عن الاسم|Asking About Name", category = "👋 التعارف والتحية|👋 Greetings & Intro", level = "HSK 1"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d3Id.toInt(), speaker = "a", hanzi = "你叫什么名字？", pinyin = "nǐ jiào shénme míngzi?", arabic = "ما اسمك؟|What is your name?"),
                DialogueLine(dialogueId = d3Id.toInt(), speaker = "b", hanzi = "我叫汉斯。你呢？", pinyin = "wǒ jiào HànSī. nǐ ne?", arabic = "اسمي هانز. وأنت؟|My name is Hans. And you?"),
                DialogueLine(dialogueId = d3Id.toInt(), speaker = "a", hanzi = "我叫本宁。", pinyin = "wǒ jiào BěnNíng.", arabic = "اسمي بنين。|My name is Benin.")
            ))

            // Dialogue 4
            val d4Id = dialogueDao.insertDialogue(Dialogue(title = "في المطار|At the Airport", category = "✈️ السفر والوجهات|✈️ Travel & Destinations", level = "HSK 2"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d4Id.toInt(), speaker = "a", hanzi = "请问，护照检查在哪里？", pinyin = "qǐngwèn, hùzhào jiǎnchá zài nǎlǐ?", arabic = "معذرة، أين فحص جوازات السفر؟|Excuse me, where is passport control?"),
                DialogueLine(dialogueId = d4Id.toInt(), speaker = "b", hanzi = "关口在那边，请跟我来。", pinyin = "guānkǒu zài nàbiān, qǐng gēn wǒ lái.", arabic = "البوابة هناك، تفضل معي。|The gate is over there, please come with me.")
            ))

            // Dialogue 5
            val d5Id = dialogueDao.insertDialogue(Dialogue(title = "حجز غرفة في الفندق|Booking a Hotel Room", category = "🏨 الفندق والإقامة|🏨 Hotel & Lodging", level = "HSK 2"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d5Id.toInt(), speaker = "a", hanzi = "我想订一个房间。", pinyin = "wǒ xiǎng dìng yí gè fángjiān.", arabic = "أود حجز غرفة。|I would like to book a room."),
                DialogueLine(dialogueId = d5Id.toInt(), speaker = "b", hanzi = "单人房还是双人房？", pinyin = "dānrén fáng háishì shuāngrén fáng?", arabic = "غرفة فردية أم مزدوجة؟|Single or double room?"),
                DialogueLine(dialogueId = d5Id.toInt(), speaker = "a", hanzi = "单人房，谢谢。", pinyin = "dānrén fáng, xièxie.", arabic = "غرفة مفردة، شكراً。|Single room, thank you.")
            ))

            // Dialogue 6
            val d6Id = dialogueDao.insertDialogue(Dialogue(title = "طلب الشاي الأخضر|Ordering Green Tea", category = "🍽️ المطعم والوجبات|🍽️ Restaurant & Meals", level = "HSK 1"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d6Id.toInt(), speaker = "a", hanzi = "服务员，我想喝茶。", pinyin = "fúwùyuán, wǒ xiǎng hē chá.", arabic = "يا جرسون، أريد شرب الشاي。|Waiter, I want to drink tea."),
                DialogueLine(dialogueId = d6Id.toInt(), speaker = "b", hanzi = "好的，您要绿茶还是红茶？", pinyin = "hǎo de, nín yào lǜchá háishì hóngchá?", arabic = "حسناً، هل تريد شاياً أخضر أم أحمر؟|Ok, do you want green or black tea?"),
                DialogueLine(dialogueId = d6Id.toInt(), speaker = "a", hanzi = "绿茶，谢谢。", pinyin = "lǜchá, xièxie.", arabic = "شاي أخضر، شكراً。|Green tea, thank you.")
            ))

            // Dialogue 7
            val d7Id = dialogueDao.insertDialogue(Dialogue(title = "مساومة البائع في السوق|Bargaining in the Market", category = "🤝 التجارة والمساومة|🤝 Commerce & Bargaining", level = "HSK 2"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d7Id.toInt(), speaker = "a", hanzi = "这个包多少钱？", pinyin = "zhège bāo duōshǎo qián?", arabic = "كم سعر هذه الحقيبة؟|How much is this bag?"),
                DialogueLine(dialogueId = d7Id.toInt(), speaker = "b", hanzi = "一百块钱。", pinyin = "yì bǎi kuài qián.", arabic = "مئة يوان。|One hundred Yuan."),
                DialogueLine(dialogueId = d7Id.toInt(), speaker = "a", hanzi = "太贵了！可以便宜点儿吗？", pinyin = "tài guì le! kěyǐ piányi diǎnr ma?", arabic = "غال جداً! هل يمكن تخفيض السعر قليلاً؟|Too expensive! Can you make it cheaper?"),
                DialogueLine(dialogueId = d7Id.toInt(), speaker = "b", hanzi = "八十块，怎么样？", pinyin = "bāshí kuài, zěnmeyàng?", arabic = "ثمانون يواناً، ما رأيك؟|80 Yuan, how about that?")
            ))

            // Dialogue 8
            val d8Id = dialogueDao.insertDialogue(Dialogue(title = "السؤال عن الوقت الحالي|Asking For Time", category = "✈️ السفر والوجهات|✈️ Travel & Destinations", level = "HSK 1"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d8Id.toInt(), speaker = "a", hanzi = "开会几点开始？现在几点？", pinyin = "kāihuì jǐ diǎn kāishǐ? xiànzài jǐ diǎn?", arabic = "في أي ساعة يبدأ الاجتماع؟ كم الساعة الآن؟|When does the meeting start? What time is it now?"),
                DialogueLine(dialogueId = d8Id.toInt(), speaker = "b", hanzi = "现在两点半。会议三点开始。", pinyin = "xiànzài liǎng diǎn bàn. huìyì sān diǎn kāishǐ.", arabic = "الساعة الآن الثانية والنصف. الاجتماع يبدأ في الثالثة。|It's half past two. The meeting starts at three.")
            ))

            // Dialogue 9
            val d9Id = dialogueDao.insertDialogue(Dialogue(title = "الذهاب لتناول الغداء|Going for Lunch", category = "🍽️ المطعم والوجبات|🍽️ Restaurant & Meals", level = "HSK 2"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d9Id.toInt(), speaker = "a", hanzi = "你想吃什么？", pinyin = "nǐ xiǎng chī shénme?", arabic = "ماذا تريد أن تأكل؟|What do you want to eat?"),
                DialogueLine(dialogueId = d9Id.toInt(), speaker = "b", hanzi = "我想吃中国菜。", pinyin = "wǒ xiǎng chī Zhōngguó cài.", arabic = "أريد أن آكل طعاماً صينياً。|I want to eat Chinese food.")
            ))

            // Dialogue 10
            val d10Id = dialogueDao.insertDialogue(Dialogue(title = "طلب الفاتورة والدفع|Paying the Bill", category = "🍽️ المطعم والوجبات|🍽️ Restaurant & Meals", level = "HSK 1"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d10Id.toInt(), speaker = "a", hanzi = "服务员，买单。可以刷卡吗？", pinyin = "fúwùyuán, mǎidān. kěyǐ shuākǎ ma?", arabic = "يا جرسون، الحساب لو سمحت. هل يمكن الدفع بالبطاقة؟|Waiter, bill please. Can I pay by card?"),
                DialogueLine(dialogueId = d10Id.toInt(), speaker = "b", hanzi = "可以的，一共两百块。", pinyin = "kěyǐ de, yígòng liǎng bǎi kuài.", arabic = "نعم يمكن، المجموع مئتا يوان。|Sure, the total is two hundred Yuan.")
            ))

            // Dialogue 11
            val d11Id = dialogueDao.insertDialogue(Dialogue(title = "البحث عن الحمام|Finding the Restroom", category = "✈️ السفر والوجهات|✈️ Travel & Destinations", level = "HSK 1"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d11Id.toInt(), speaker = "a", hanzi = "请问洗手间在哪里？", pinyin = "qǐngwèn xǐshǒujiān zài nǎlǐ?", arabic = "معذرة، أين الحمام؟|Excuse me, where is the restroom?"),
                DialogueLine(dialogueId = d11Id.toInt(), speaker = "b", hanzi = "在电梯右边，过道尽头。", pinyin = "zài diàntī yòubiān, guòdào jìntóu.", arabic = "على يمين المصعد، في نهاية الممر。|On the right of the elevator, at the end of the aisle.")
            ))

            // Dialogue 12
            val d12Id = dialogueDao.insertDialogue(Dialogue(title = "الهوايات والأنشطة|Hobbies & Activities", category = "👋 التعارف والتحية|👋 Greetings & Intro", level = "HSK 2"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d12Id.toInt(), speaker = "a", hanzi = "你有什么爱好？", pinyin = "nǐ yǒu shénme àihào?", arabic = "ما هي هواياتك؟|What are your hobbies?"),
                DialogueLine(dialogueId = d12Id.toInt(), speaker = "b", hanzi = "我喜欢听音乐和看书。", pinyin = "wǒ xǐhuan tīng yīnyuè hé kànshū.", arabic = "أحب الاستماع للموسيقى وقراءة الكتب。|I like listening to music and reading books.")
            ))

            // Dialogue 13
            val d13Id = dialogueDao.insertDialogue(Dialogue(title = "الوداع والافتراق اللطيف|Polite Farewell", category = "👋 التعارف والتحية|👋 Greetings & Intro", level = "HSK 1"))
            dialogueDao.insertDialogueLines(listOf(
                DialogueLine(dialogueId = d13Id.toInt(), speaker = "a", hanzi = "时间不早了，我得走了。", pinyin = "shíjiān bù zǎo le, wǒ děi zǒu le.", arabic = "الوقت تأخر، يجب أن أذهب。|It is getting late, I must go."),
                DialogueLine(dialogueId = d13Id.toInt(), speaker = "b", hanzi = "慢走，再见！有空再联系！", pinyin = "màn zǒu, zàijiàn! yǒu kòng zài liánxì!", arabic = "رافقتك السلامة، إلى اللقاء! تواصل معي عندما تتفرغ!|Take care, goodbye! Let's keep in touch when you're free!")
            ))

            // Dynamic seed details pool
            val genSubjects = listOf(
                Triple("阿合麦德", "Āhémàidé", Pair("أحمد", "Ahmed")),
                Triple("萨利姆", "Sālǐmǔ", Pair("سالم", "Salim")),
                Triple("大卫", "Dàwèi", Pair("ديفيد", "David")),
                Triple("王老师", "Wáng lǎoshī", Pair("الأستاذ وانغ", "Teacher Wang")),
                Triple("李明", "Lǐ Míng", Pair("لي مينغ", "Li Ming")),
                Triple("张经理", "Zhāng jīnglǐ", Pair("المدير تشانغ", "Manager Zhang")),
                Triple("法蒂玛", "Fātǐmǎ", Pair("فاطمة", "Fatima")),
                Triple("玛丽", "Mǎlì", Pair("ماري", "Mary")),
                Triple("哈立德", "Hālìdé", Pair("خالد", "Khalid")),
                Triple("优素福", "Yōusùfú", Pair("يوسف", "Youssef")),
                Triple("阿伊莎", "Āyīshā", Pair("عائشة", "Aisha")),
                Triple("丽娜", "Lìnà", Pair("لينا", "Lina"))
            )

            val genPlaces = listOf(
                Triple("火车站", "huǒchēzhàn", Pair("محطة القطار", "the train station")),
                Triple("飞机场", "fēijīchǎng", Pair("المطار الدولي", "the airport")),
                Triple("中国餐馆", "Zhōngguó cānguǎn", Pair("المطعم الصيني", "the Chinese restaurant")),
                Triple("大酒店", "dà jiǔdiàn", Pair("الفندق الكبير", "the big hotel")),
                Triple("茶馆", "cháguǎn", Pair("المقهى الصيني التقليدي", "the traditional teahouse")),
                Triple("超级市场", "chāojí shìchǎng", Pair("السوبرماركت الكبير", "the supermarket")),
                Triple("洗手间", "xǐshǒujiān", Pair("دورة المياه / الحمام", "the restroom")),
                Triple("地铁站", "dìtiězhàn", Pair("محطة مترو الأنفاق", "the subway station")),
                Triple("附近商圈", "fùjìn shāngquān", Pair("المنطقة التجارية المجاورة", "the nearby business district")),
                Triple("市中心", "shì zhōngxīn", Pair("وسط المدينة", "the city center")),
                Triple("图书馆", "túshūguǎn", Pair("المكتبة العامة", "the public library")),
                Triple("北京大学", "Běijīng Dàxué", Pair("جامعة بكين", "Peking University"))
            )

            val genItems = listOf(
                Triple("绿茶", "lǜchá", Pair("الشاي الأخضر", "green tea")),
                Triple("中国菜", "Zhōngguó cài", Pair("الطعام الصيني الشهي", "delicious Chinese food")),
                Triple("皮包", "píbāo", Pair("الحقيبة الجلدية", "the leather bag")),
                Triple("汉语书", "Hànyǔ shū", Pair("كتاب اللغة الصينية", "the Chinese book")),
                Triple("单人房", "dānrén fáng", Pair("غرفة النوم المفردة", "the single bedroom")),
                Triple("苹果", "píngguǒ", Pair("التفاح الطازج", "fresh apples")),
                Triple("矿泉水", "kuàngquánshuǐ", Pair("المياه المعدنية الباردة", "cold mineral water")),
                Triple("饺子", "jiǎozi", Pair("وجبة الزلابية الصينية", "Chinese dumplings")),
                Triple("面条", "miàntiáo", Pair("النودلز الصينية", "Chinese noodles")),
                Triple("咖啡", "kāfēi", Pair("القهوة الدافئة", "warm coffee")),
                Triple("红茶", "hóngchá", Pair("الشاي الأحمر", "black tea")),
                Triple("手机", "shǒujī", Pair("الهاتف المحمول", "the cell phone"))
            )

            var dialogueCounter = 14

            // Category 1: Greetings (👋 التعارف والتحية) - 180 dialogues
            for (i in 0 until 180) {
                val subj1 = genSubjects[i % genSubjects.size]
                val item = genItems[i % genItems.size]
                val dId = dialogueDao.insertDialogue(Dialogue(
                    title = "محادثة تعارف رقم $dialogueCounter|Introduction Dialogue #$dialogueCounter",
                    category = "👋 التعارف والتحية|👋 Greetings & Intro",
                    level = "HSK 1"
                ))
                dialogueDao.insertDialogueLines(listOf(
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "你好 ${subj1.first}，很高兴认识你！", pinyin = "nǐ hǎo ${subj1.second}, hěn gāoxìng rènshi nǐ!", arabic = "مرحباً يا ${subj1.third.first}، سعيد جداً بلقائك!|Hello ${subj1.third.second}, very pleased to meet you!"),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "b", hanzi = "你好！很高兴认识你，你喜欢 ${item.first} 吗？", pinyin = "nǐ hǎo! hěn gāoxìng rènshi nǐ, nǐ xǐhuan ${item.second} ma?", arabic = "مرحباً! سعيد أيضاً بلقائك، هل تحب ${item.third.first}؟|Hello! I'm also pleased to meet you, do you like ${item.third.second}?"),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "是的，我非常喜欢 ${item.first} 并热爱学习汉语。", pinyin = "shì de, wǒ fēicháng xǐhuan ${item.second} bìng rè’ài xuéxí Hànyǔ.", arabic = "نعم، أنا معجب جداً بـ ${item.third.first} وأحب دراسة الصينية。|Yes, I like ${item.third.second} very much and I love studying Chinese.")
                ))
                dialogueCounter++
            }

            // Category 2: Travel (✈️ السفر والوجهات) - 180 dialogues
            for (i in 0 until 180) {
                val subj1 = genSubjects[i % genSubjects.size]
                val place = genPlaces[i % genPlaces.size]
                val dId = dialogueDao.insertDialogue(Dialogue(
                    title = "طلب مساعدة في السفر رقم $dialogueCounter|Travel Assistance Request #$dialogueCounter",
                    category = "✈️ السفر والوجهات|✈️ Travel & Destinations",
                    level = "HSK 2"
                ))
                dialogueDao.insertDialogueLines(listOf(
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "请问 ${subj1.first}，请教一下 ${place.first} 在哪个方向？", pinyin = "qǐngwèn ${subj1.second}, qǐngjiào yíxià ${place.second} zài nǎge fāngxiàng?", arabic = "لو سمحت يا ${subj1.third.first}، أين يقع اتجاه ${place.third.first} من فضلك؟|Excuse me ${subj1.third.second}, which direction is ${place.third.second}, please?"),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "b", hanzi = "你好！ ${place.first} 就在前面的路口，右转直走即到。", pinyin = "nǐ hǎo! ${place.second} jiù zài qiánmiàn de lùkǒu, yòuzuǎn zhí zǒu jí dào.", arabic = "مرحباً! ${place.third.first} تقع عند التقاطع الأمامي مباشرة، انعطف يميناً وامشِ طويلاً。|Hello! ${place.third.second} is right at the intersection ahead, turn right and go straight."),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "好的，太感谢您的热心指路了！", pinyin = "hǎo de, tài gǎnxiè nín de rèxīn zhǐlù le!", arabic = "حسناً، شكراً جزيلاً لمرشدك وتوجيهك اللطيف!|Okay, thank you so much for your kind directions!")
                ))
                dialogueCounter++
            }

            // Category 3: Restaurant (🍽️ المطعم والوجبات) - 170 dialogues
            for (i in 0 until 170) {
                val subj1 = genSubjects[i % genSubjects.size]
                val item = genItems[i % genItems.size]
                val dId = dialogueDao.insertDialogue(Dialogue(
                    title = "حوار في المطعم والوجبات رقم $dialogueCounter|Restaurant Dialogue #$dialogueCounter",
                    category = "🍽️ المطعم والوجبات|🍽️ Restaurant & Meals",
                    level = "HSK 1"
                ))
                dialogueDao.insertDialogueLines(listOf(
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "服务员，我想吃一份新鲜的 ${item.first} 吗？", pinyin = "fúwùyuán, wǒ xiǎng chī yí fèn xīnxiān de ${item.second} ma?", arabic = "يا جرسون، أرغب في تناول وجبة من ${item.third.first} الطازج؟|Waiter, would I like to have a serving of fresh ${item.third.second}?"),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "b", hanzi = "好的！我们這儿做的 ${item.first} 在北京非常有名。", pinyin = "hǎo de! wǒmen zhèi’er zuò de ${item.second} zài Běijīng fēicháng yǒumíng.", arabic = "حسناً! الـ ${item.third.first} الذي نصنعه هنا مشهور جداً في بكين。|Okay! The ${item.third.second} we make here is very famous in Beijing."),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "那太棒了，再给我来一杯茶，辛苦你了！", pinyin = "nà tài bàng le, zài gěi wǒ lái yì bēi chá, xīnkǔ nǐ le!", arabic = "هذا مذهل للغاية، أحضر لي كأساً من الشاي أيضاً، يعطيك العافية!|That's awesome, bring me a cup of tea as well. Thanks for your hard work!")
                ))
                dialogueCounter++
            }

            // Category 4: Hotel (🏨 الفندق والإقامة) - 165 dialogues
            for (i in 0 until 165) {
                val subj1 = genSubjects[i % genSubjects.size]
                val item = genItems[i % genItems.size]
                val dId = dialogueDao.insertDialogue(Dialogue(
                    title = "تفاصيل حجز الغرفة في الفندق رقم $dialogueCounter|Hotel Booking Details #$dialogueCounter",
                    category = "🏨 الفندق والإقامة|🏨 Hotel & Lodging",
                    level = "HSK 2"
                ))
                dialogueDao.insertDialogueLines(listOf(
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "您好，开一间舒适的 ${item.first} 可以用护照预定吗？", pinyin = "nínhǎo, kāi yì jiān shūshì de ${item.second} kěyǐ yòng hùzhào yùdìng ma?", arabic = "مرحباً، هل يمكن حجز ${item.third.first} المريحة لليوم باستخدام جواز السفر؟|Hello, can I reserve a comfortable ${item.third.second} for today using my passport?"),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "b", hanzi = "没问题，一晚两百块钱，您先登记一下信息。", pinyin = "méi wèntí, yì wǎn liǎngbǎi kuài qián, nín xiān dēngjì yíxià xìnxī.", arabic = "دون أدنى مشكلة، السعر هو 200 يوان لليلة، يرجى تسجيل بياناتك أولاً。|No problem, it's 200 Yuan a night. Please register your information first."),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "好的，这是本宁의护照，谢谢你。", pinyin = "hǎo de, zhè  shì BěnNíng de hùzhào, xièxie nǐ.", arabic = "حسناً، هذا جواز سفر بنين، شكراً جزيلاً لك。|Okay, this is Benin's passport, thank you very much.")
                ))
                dialogueCounter++
            }

            // Category 5: Commerce/Business (🤝 التجارة والمساومة) - 165 dialogues
            for (i in 0 until 165) {
                val subj1 = genSubjects[i % genSubjects.size]
                val item = genItems[i % genItems.size]
                val dId = dialogueDao.insertDialogue(Dialogue(
                    title = "مساومة البائع وعقد صفقة رقم $dialogueCounter|Seller Bargaining #$dialogueCounter",
                    category = "🤝 التجارة والمساومة|🤝 Commerce & Bargaining",
                    level = "HSK 2"
                ))
                dialogueDao.insertDialogueLines(listOf(
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "老板，你店里的这个 ${item.first} 卖多少钱？", pinyin = "lǎobǎn, nǐ diàn lǐ de zhège ${item.second} mài duōshǎo qián?", arabic = "يا معلم، كم تبيع الـ ${item.third.first} هذا في متجرك؟|Boss, how much do you sell this ${item.third.second} in your shop?"),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "b", hanzi = "这个质量特别好，一百八十块，不可以便宜了。", pinyin = "zhège zhìliàng tèbié hǎo, yìbāshí kuài, bù kěyǐ piányi le.", arabic = "هذا ذو جودة عالية جداً، السعر هو 180 يواناً ولا يمكن تخفيضه أبدًا。|This quality is exceptionally good, 180 Yuan, no discount possible."),
                    DialogueLine(dialogueId = dId.toInt(), speaker = "a", hanzi = "一百块卖不卖？不行我就去旁边的商店购买了。", pinyin = "yìbǎi kuài mài bú mài? bùxíng wǒ jiù qù pángbiān de shāngdiàn gòumǎi le.", arabic = "هل تبيعه بمئة يوان؟ إن لم يكن، فسأذهب للمحل المجاور للشراء。|Will you sell it for 100 Yuan? If not, I'll go buy from the shop next door.")
                ))
                dialogueCounter++
            }
            
            sharedPrefs.edit().putBoolean("dialogues_translated_v1", true).apply()
        }
    }
}
