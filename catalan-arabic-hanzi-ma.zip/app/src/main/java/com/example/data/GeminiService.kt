package com.example.data

import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.io.IOException
import java.util.concurrent.TimeUnit

// ==========================================
// 1. نماذج البيانات (Data Classes) الخاصة بـ Moshi
// ==========================================

@JsonClass(generateAdapter = true)
data class Part(val text: String?)

@JsonClass(generateAdapter = true)
data class Content(val parts: List<Part>)

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(val contents: List<Content>)

@JsonClass(generateAdapter = true)
data class Candidate(val content: Content)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(val candidates: List<Candidate>?)

// ==========================================
// 2. واجهة الاتصال (API Interface)
// ==========================================

interface GeminiApiService {
    // تم تحديث الموديل إلى gemini-2.5-flash لضمان أعلى استقرار وسرعة استجابة
    @POST("v1beta/models/gemini-2.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

// ==========================================
// 3. عميل ريتروفيت (Retrofit Client)
// ==========================================

object RetrofitClient {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val geminiService: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }
}

// ==========================================
// 4. دالة الاستدعاء وفحص الاتصال (Repository / Execution Function)
// ==========================================

object GeminiRepository {

    /**
     * دالة إرسال الطلب لـ Gemini مع فحص ومعالجة أخطاء الشبكة والسيرفر.
     * @param apiKey مفتاح الـ API الخاص بـ Gemini
     * @param userPrompt النص الذي كتبه المستخدم
     * @param onResult دالة برمجية (Callback) تعيد النتيجة أو رسالة الخطأ لتحديث الواجهة (UI)
     */
    suspend fun askGemini(
        apiKey: String, 
        userPrompt: String, 
        onResult: (String) -> Unit
    ) {
        // تجهيز بيانات الطلب هيكلياً
        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = userPrompt))))
        )

        // تحويل مسار التنفيذ إلى الـ IO Thread المخصص للشبكات
        withContext(Dispatchers.IO) {
            try {
                // محاولة إرسال الطلب واستقبال النتيجة
                val response = RetrofitClient.geminiService.generateContent(apiKey, request)
                
                // استخراج النص من الاستجابة بأمان
                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                
                if (replyText != null) {
                    onResult(replyText) // نجاح العملية وإرسال الرد للواجهة
                } else {
                    onResult("⚠️ استجاب السيرفر بنجاح، ولكن لم يتم العثور على رد مناسب.")
                }

            } catch (e: IOException) {
                // 🛑 التقاط خطأ عدم وجود اتصال بالإنترنت (Offline / Timeout)
                onResult("❌ لا يوجد اتصال بالإنترنت! يرجى التحقق من شبكة الواي فاي أو بيانات الهاتف المحمول.")
                
            } catch (e: HttpException) {
                // ⚠️ التقاط خطأ السيرفر (مثل مفتاح API خاطئ، أو انتهاء الحصة المجانية الكوتا)
                val errorCode = e.code()
                when (errorCode) {
                    400 -> onResult("🚫 خطأ (400): الطلب غير صحيح، يرجى مراجعة صياغة النص.")
                    403 -> onResult("🔑 خطأ (403): مفتاح الـ API غير صحيح، أو غير مصرح له بالوصول.")
                    429 -> onResult("⏳ خطأ (429): لقد تجاوزت معدل الطلبات المسموح به حالياً، انتظر دقيقة وأعد المحاولة.")
                    else -> onResult("⚙️ خطأ من خوادم جوجل (رمز الخطأ: $errorCode).")
                }
                
            } catch (e: Exception) {
                // التقاط أي أخطاء جانبية أخرى غير متوقعة
                onResult("⚠️ حدث خطأ غير متوقع: ${e.localizedMessage}")
            }
        }
    }
}
