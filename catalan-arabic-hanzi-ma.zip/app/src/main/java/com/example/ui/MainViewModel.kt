package com.example.ui

import android.app.Application
import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

enum class AppTab {
    HOME, VOCAB, CONVERSATIONS, AI, EXERCISES, SETTINGS
}

enum class ExerciseType {
    NONE, QUIZ, FLASHCARD
}

data class ChatMessage(
    val content: String,
    val isUser: Boolean,
    val isLoading: Boolean = false
)

data class QuizState(
    val questions: List<VocabularyWord> = emptyList(),
    val currentIndex: Int = 0,
    val scoreCorrect: Int = 0,
    val scoreWrong: Int = 0,
    val options: List<VocabularyWord> = emptyList(),
    val selectedOption: VocabularyWord? = null,
    val isAnswered: Boolean = false
)

data class FlashcardState(
    val cards: List<VocabularyWord> = emptyList(),
    val currentIndex: Int = 0,
    val isFlipped: Boolean = false,
    val scoreKnown: Int = 0
)

class MainViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val database = AppDatabase.getDatabase(application)
    private val repository = ChineseRepository(database.vocabularyDao(), database.dialogueDao())

    private val sharedPrefs = application.getSharedPreferences("huayutong_prefs", Context.MODE_PRIVATE)

    // --- State Flows ---

    val currentTab = MutableStateFlow(AppTab.HOME)

    // Persistent XP and Streak day metrics
    val userXP = MutableStateFlow(sharedPrefs.getInt("user_xp", 0))
    val userStreak = MutableStateFlow(sharedPrefs.getInt("user_streak", 0))
    
    // Theme options and daily reminders toggle
    val themeMode = MutableStateFlow(sharedPrefs.getString("theme_mode", "dark") ?: "dark")
    val colorTheme = MutableStateFlow(sharedPrefs.getString("color_theme", "gold") ?: "gold")
    val dailyNotifications = MutableStateFlow(sharedPrefs.getBoolean("daily_notifications", true))
    val appLanguage = MutableStateFlow(sharedPrefs.getString("app_language", "ar") ?: "ar")

    // Bookmarking and Completed status maps
    val savedWordIds = MutableStateFlow<Set<String>>(
        sharedPrefs.getStringSet("saved_word_ids", emptySet()) ?: emptySet()
    )
    val completedWordIds = MutableStateFlow<Set<String>>(
        sharedPrefs.getStringSet("completed_word_ids", emptySet()) ?: emptySet()
    )

    // Interstitial Ad metrics and counters
    val testClickCount = MutableStateFlow(sharedPrefs.getInt("test_click_count", 0))
    val showInterstitialAd = MutableStateFlow(false)

    // Playback Settings
    val speechSpeed = MutableStateFlow(sharedPrefs.getFloat("speech_speed", 1.0f))
    val autoSpeak = MutableStateFlow(sharedPrefs.getBoolean("auto_speak", true))

    // Database Flows
    private val _allWords = repository.allWords.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    private val _allDialogues = repository.allDialogues.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allAvailableWords = _allWords
    val allAvailableDialogues = _allDialogues

    // UI Filters
    val vocabSearchQuery = MutableStateFlow("")
    val selectedVocabFilter = MutableStateFlow("الكل") // "الكل", "HSK 1", "HSK 2", etc.
    val selectedDialogueCategory = MutableStateFlow("all") // "all", "greetings", "travel", etc.

    // Conversation Details cache
    val selectedDialogueLines = MutableStateFlow<List<DialogueLine>>(emptyList())
    val selectedDialogueTitle = MutableStateFlow("")

    // Daily Word (Randomized relative to offline dataset)
    val dailyWord = MutableStateFlow<VocabularyWord?>(null)

    // Filtered lists for UI rendering
    val filteredWords = combine(
        _allWords, 
        vocabSearchQuery, 
        selectedVocabFilter, 
        savedWordIds, 
        completedWordIds
    ) { words, query, filter, savedSet, completedSet ->
        words.filter { word ->
            val matchesQuery = query.isEmpty() ||
                    word.hanzi.contains(query, ignoreCase = true) ||
                    word.pinyin.contains(query, ignoreCase = true) ||
                    word.arabic.contains(query, ignoreCase = true) ||
                    word.english.contains(query, ignoreCase = true)

            val matchesFilter = when {
                filter == "الكل" -> true
                filter == "المحفوظة ❤️" -> savedSet.contains(word.id.toString())
                filter == "المكتملة ✅" -> completedSet.contains(word.id.toString())
                filter.startsWith("HSK") -> {
                    val lvl = filter.replace("\\D".toRegex(), "").toIntOrNull() ?: 1
                    word.level == lvl
                }
                else -> word.category == filter
            }
            matchesQuery && matchesFilter
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredDialogues = combine(_allDialogues, selectedDialogueCategory) { dialogues, category ->
        dialogues.filter { dialogue ->
            category == "all" || when (category) {
                "greetings" -> dialogue.category.contains("التعارف")
                "travel" -> dialogue.category.contains("السفر")
                "restaurant" -> dialogue.category.contains("المطعم")
                "hotel" -> dialogue.category.contains("الفندق")
                "business" -> dialogue.category.contains("التجارة")
                else -> false
            }
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Exercises (Quiz & Flashcards) States
    val currentExerciseType = MutableStateFlow(ExerciseType.NONE)
    val quizState = MutableStateFlow(QuizState())
    val flashcardState = MutableStateFlow(FlashcardState())

    // Level up reward dialogue pop tracker
    val showCelebrationDialog = MutableStateFlow(false)
    val lastEarnedXP = MutableStateFlow(0)

    // Gemini Chat Messages Flow
    val chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                content = "مرحباً بك! أنا رفيقك ومساعدك اللغوي اللطيف. اسألني عن أي جزئية في قواعد اللغة الصينية، معاني ومفردات الكلمات، طريقة نطق بينيين بنغماته الأربعة (Pinyin)، أو صياغة عبارات وحوارات متكاملة. سأجيبك باختصار وموضوعية وهدف صريح! 💬🇨🇳",
                isUser = false
            )
        )
    )

    // --- Native TTS Interface Setup ---
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    init {
        tts = TextToSpeech(application, this)
        
        viewModelScope.launch {
            repository.preloadData(application)
            // Randomly select daily word from preloaded list
            _allWords.collectLatest { list ->
                if (list.isNotEmpty() && dailyWord.value == null) {
                    dailyWord.value = list.random()
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.CHINESE)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsReady = true
            }
        }
    }

    fun speakChinese(text: String) {
        if (isTtsReady) {
            tts?.setSpeechRate(speechSpeed.value)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    // --- State setters ---

    fun switchTab(tab: AppTab) {
        currentTab.value = tab
    }

    fun updateSpeechSpeed(speed: Float) {
        speechSpeed.value = speed
        sharedPrefs.edit().putFloat("speech_speed", speed).apply()
    }

    fun updateAutoSpeak(enabled: Boolean) {
        autoSpeak.value = enabled
        sharedPrefs.edit().putBoolean("auto_speak", enabled).apply()
    }

    fun updateThemeMode(mode: String) {
        themeMode.value = mode
        sharedPrefs.edit().putString("theme_mode", mode).apply()
    }

    fun updateColorTheme(theme: String) {
        colorTheme.value = theme
        sharedPrefs.edit().putString("color_theme", theme).apply()
    }

    fun updateDailyNotifications(enabled: Boolean) {
        dailyNotifications.value = enabled
        sharedPrefs.edit().putBoolean("daily_notifications", enabled).apply()
    }

    fun updateAppLanguage(lang: String) {
        appLanguage.value = lang
        sharedPrefs.edit().putString("app_language", lang).apply()
    }

    fun registerTestClick() {
        val nextVal = testClickCount.value + 1
        testClickCount.value = nextVal
        sharedPrefs.edit().putInt("test_click_count", nextVal).apply()
        if (nextVal > 0 && nextVal % 3 == 0) {
            showInterstitialAd.value = true
        }
    }

    fun dismissInterstitial() {
        showInterstitialAd.value = false
    }

    fun learnWord(word: VocabularyWord) {
        val learnedSet = sharedPrefs.getStringSet("learned_word_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        if (!learnedSet.contains(word.id.toString())) {
            learnedSet.add(word.id.toString())
            sharedPrefs.edit().putStringSet("learned_word_ids", learnedSet).apply()
            addXP(10) // +10 XP for explicitly learning/viewing a new phrase/word format
        }
    }

    fun toggleSaveWord(word: VocabularyWord) {
        val currentSaved = savedWordIds.value.toMutableSet()
        val wordIdStr = word.id.toString()
        val isSavedBefore = currentSaved.contains(wordIdStr)
        if (isSavedBefore) {
            currentSaved.remove(wordIdStr)
        } else {
            currentSaved.add(wordIdStr)
            addXP(10) // +10 XP for bookmarking / saving a word!
        }
        sharedPrefs.edit().putStringSet("saved_word_ids", currentSaved).apply()
        savedWordIds.value = currentSaved
    }

    fun toggleCompleteWord(word: VocabularyWord) {
        val currentCompleted = completedWordIds.value.toMutableSet()
        val wordIdStr = word.id.toString()
        val isCompletedBefore = currentCompleted.contains(wordIdStr)
        if (isCompletedBefore) {
            currentCompleted.remove(wordIdStr)
        } else {
            currentCompleted.add(wordIdStr)
            addXP(15) // +15 XP for completing / mastering a word!
        }
        sharedPrefs.edit().putStringSet("completed_word_ids", currentCompleted).apply()
        completedWordIds.value = currentCompleted
    }

    fun startQuizForCategory(category: String, level: Int?) {
        registerTestClick()
        currentExerciseType.value = ExerciseType.QUIZ
        val allList = _allWords.value
        val filteredList = allList.filter { word ->
            (level == null || word.level == level) && 
            (category == "الكل" || word.category == category)
        }
        val targetList = if (filteredList.isNotEmpty()) filteredList else allList
        val questions = targetList.shuffled().take(10)
        quizState.value = QuizState(questions = questions, currentIndex = 0)
        loadQuizQuestion()
    }

    fun addXP(amount: Int) {
        val nextXP = userXP.value + amount
        userXP.value = nextXP
        sharedPrefs.edit().putInt("user_xp", nextXP).apply()

        // Set streak on first answer points
        if (userStreak.value == 0) {
            userStreak.value = 1
            sharedPrefs.edit().putInt("user_streak", 1).apply()
        }

        lastEarnedXP.value = amount
        showCelebrationDialog.value = true
        speakChinese("恭喜") // Celebrate!
    }

    fun closeCelebration() {
        showCelebrationDialog.value = false
    }

    fun resetProgress() {
        userXP.value = 0
        userStreak.value = 0
        testClickCount.value = 0
        sharedPrefs.edit().clear().apply() // Clear all preferences including learned word sets and settings safely
        
        // Re-establish keys defaults
        sharedPrefs.edit().apply {
            putInt("user_xp", 0)
            putInt("user_streak", 0)
            putFloat("speech_speed", 1.0f)
            putBoolean("auto_speak", true)
            putString("theme_mode", "dark")
            putString("color_theme", "gold")
            putBoolean("daily_notifications", true)
            putInt("test_click_count", 0)
        }.apply()
        
        speechSpeed.value = 1.0f
        autoSpeak.value = true
        themeMode.value = "dark"
        colorTheme.value = "gold"
        dailyNotifications.value = true
        savedWordIds.value = emptySet()
        completedWordIds.value = emptySet()
    }

    // --- Dialogue details fetcher ---

    fun loadDialogueLines(dialogue: Dialogue) {
        viewModelScope.launch {
            val lines = repository.getLinesForDialogue(dialogue.id)
            selectedDialogueLines.value = lines
            selectedDialogueTitle.value = dialogue.title
        }
    }

    // --- Exercises Controller ---

    fun startQuiz() {
        registerTestClick()
        currentExerciseType.value = ExerciseType.QUIZ
        val allList = _allWords.value
        if (allList.isNotEmpty()) {
            val questions = allList.shuffled().take(10)
            quizState.value = QuizState(questions = questions, currentIndex = 0)
            loadQuizQuestion()
        }
    }

    private fun loadQuizQuestion() {
        val state = quizState.value
        if (state.currentIndex >= state.questions.size) {
            // Completed quiz! Add reward points dynamically based on correct answers
            val earnedXP = (state.scoreCorrect * 15) + 15 // +15 per correct answer + 15 completion bonus
            addXP(earnedXP)
            currentExerciseType.value = ExerciseType.NONE
            return
        }

        val question = state.questions[state.currentIndex]
        val options = mutableListOf(question)
        val availableDecoys = _allWords.value.filter { it.id != question.id }
        if (availableDecoys.isNotEmpty()) {
            options.addAll(availableDecoys.shuffled().take(3))
        }
        options.shuffle()

        quizState.value = state.copy(
            options = options,
            selectedOption = null,
            isAnswered = false
        )

        if (autoSpeak.value) {
            speakChinese(question.hanzi)
        }
    }

    fun answerQuiz(option: VocabularyWord) {
        val state = quizState.value
        if (state.isAnswered) return

        val correctAnswer = state.questions[state.currentIndex]
        val isCorrect = option.id == correctAnswer.id
        val nextScoreCorrect = if (isCorrect) state.scoreCorrect + 1 else state.scoreCorrect
        val nextScoreWrong = if (!isCorrect) state.scoreWrong + 1 else state.scoreWrong

        quizState.value = state.copy(
            selectedOption = option,
            isAnswered = true,
            scoreCorrect = nextScoreCorrect,
            scoreWrong = nextScoreWrong
        )
    }

    fun nextQuizStep() {
        val state = quizState.value
        quizState.value = state.copy(
            currentIndex = state.currentIndex + 1
        )
        loadQuizQuestion()
    }

    fun startFlashcards() {
        registerTestClick()
        currentExerciseType.value = ExerciseType.FLASHCARD
        val allList = _allWords.value
        if (allList.isNotEmpty()) {
            val cards = allList.shuffled().take(15)
            flashcardState.value = FlashcardState(cards = cards, currentIndex = 0, isFlipped = false, scoreKnown = 0)
            if (autoSpeak.value && cards.isNotEmpty()) {
                speakChinese(cards[0].hanzi)
            }
        }
    }

    fun flipFlashcard() {
        val state = flashcardState.value
        val nextFlipped = !state.isFlipped
        flashcardState.value = state.copy(isFlipped = nextFlipped)
        if (nextFlipped && state.currentIndex < state.cards.size) {
            speakChinese(state.cards[state.currentIndex].hanzi)
        }
    }

    fun answerFlashcard(knewIt: Boolean) {
        val state = flashcardState.value
        val nextScoreKnown = if (knewIt) state.scoreKnown + 1 else state.scoreKnown
        val nextIndex = state.currentIndex + 1
        if (nextIndex >= state.cards.size) {
            // Completed! Calculate score points precisely
            val earnedXP = (nextScoreKnown * 10) + 15 // +10 per correct cards + 15 completion bonus
            addXP(earnedXP)
            currentExerciseType.value = ExerciseType.NONE
        } else {
            flashcardState.value = state.copy(
                currentIndex = nextIndex,
                isFlipped = false,
                scoreKnown = nextScoreKnown
            )
            if (autoSpeak.value) {
                speakChinese(state.cards[nextIndex].hanzi)
            }
        }
    }

    // --- Gemini AI Assistant Query ---

    fun sendAIChat(query: String) {
        if (query.trim().isEmpty()) return

        val cleanQuery = query.trim()
        val currentList = chatMessages.value.toMutableList()
        currentList.add(ChatMessage(cleanQuery, isUser = true))
        
        val aiPlaceholderIndex = currentList.size
        currentList.add(ChatMessage("", isUser = false, isLoading = true))
        chatMessages.value = currentList

        viewModelScope.launch {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "AQ.Ab8RN6LnfSBNCV4KqCIbQNuqVDgDMvuzWEq2LOAJrslztYMc9Q") {
                // Standalone safe fallback response in case user has not provisioned the key in security secrets yet
                withContext(Dispatchers.IO) {
                    kotlinx.coroutines.delay(1500)
                }
                val fallbackResponse = "أهلاً بك! لقد تلقيت استفسارك حول:\n\"$cleanQuery\"\nيرجى تهيئة مفتاح API الخاص بك (GEMINI_API_KEY) في لوحة الأسرار (Secrets) بـ AI Studio للحصول على ترجمة وتفسير تفاعلي حي من نموذج Gemini 3.5 Flash بخصوص النطق والرموز الصينية بدقة تامة!"
                updateChatMessageAt(aiPlaceholderIndex, fallbackResponse)
            } else {
                try {
                    val prompt = """
                       
أنت مساعد ذكي متخصص في تعليم اللغة الصينية (المندرين).
تدعم التواصل باللغتين العربية والإنجليزية.

قواعدك:
- اكتشف لغة المستخدم تلقائياً وأجبه بنفس اللغة
- إذا تكلم بالعربية → أجب بالعربية
- إذا تكلم بالإنجليزية → أجب بالإنجليزية
- دائماً اكتب الكلمات الصينية هكذا: 汉字 (pīnyīn) - المعنى
- أعط أمثلة جمل بسيطة وعملية
- اشرح قواعد النطق بوضوح
- كن مشجعاً وإيجابياً مع المتعلم
- اختصر الإجابات وابتعد عن التعقيد   """.trimIndent()

                    val request = GenerateContentRequest(
                        contents = listOf(Content(parts = listOf(Part(text = prompt))))
                    )

                    val response = RetrofitClient.geminiService.generateContent(apiKey, request)
                    val resultText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                        ?: "عذراً، لم تنجح عملية توليد الإجابة الحالية. يرجى المحاولة مرة أخرى."
                    
                    updateChatMessageAt(aiPlaceholderIndex, resultText)

                } catch (e: Exception) {
                    updateChatMessageAt(aiPlaceholderIndex, "خطأ في الاتصال بالذكاء الاصطناعي: ${e.localizedMessage}. يرجى التحقق من اتصال الإنترنت ومن مفتاح GEMINI_API_KEY.")
                }
            }
        }
    }

    private fun updateChatMessageAt(index: Int, content: String) {
        val currentList = chatMessages.value.toMutableList()
        if (index < currentList.size) {
            currentList[index] = ChatMessage(content, isUser = false, isLoading = false)
            chatMessages.value = currentList
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
