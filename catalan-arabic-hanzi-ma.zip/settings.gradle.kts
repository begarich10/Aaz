pluginManagement {
    val isGradle9 = gradle.gradleVersion.startsWith("9")
    val agpVersion = if (isGradle9) "8.7.3" else "8.2.2"
    val kotlinVersion = if (isGradle9) "2.0.21" else "1.9.22"
    val kspVersion = if (isGradle9) "2.0.21-1.0.27" else "1.9.22-1.0.17"

    plugins {
        id("com.android.application") version agpVersion
        id("org.jetbrains.kotlin.android") version kotlinVersion
        id("com.google.devtools.ksp") version kspVersion
        if (isGradle9) {
            id("org.jetbrains.kotlin.plugin.compose") version kotlinVersion
        }
    }
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven { url = uri("https://developer.huawei.com/repo/") }
    }
}

plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://developer.huawei.com/repo/") }
    }
}

rootProject.name = "Huayutong"

include(":app")
